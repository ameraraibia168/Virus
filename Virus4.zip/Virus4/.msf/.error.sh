cd
pkg install unstable-repo

pkg install metasploit

cd
cd metasploit-framework
bundle update nokogiri


