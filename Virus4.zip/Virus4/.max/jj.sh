cd $HOME/Virus4/.max
chmod +x .mkm.php
php .mkm.php
