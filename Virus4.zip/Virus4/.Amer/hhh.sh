c='\033[1;36m'
g='\033[1;32m'
r='\033[1;31m'
yellow='\033[1;33m'
b='\033[1;34m'
purple='\033[1;35m'
yr='\033[0m'


echo -e $c"["$g"▇                           "$c"]"
sleep 0.1
clear
echo -e $c"["$g"▇▇                          "$c"]"
sleep 0.2
clear
echo -e $c"["$g"▇▇▇                         "$c"]"
sleep 0.3
clear
echo -e $c"["$g"▇▇▇▇                        "$c"]"
sleep 0.4
echo -e $b"-------------->"$r"remove "
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇                       "$c"]"
sleep 0.5
clear
echo -e $c"["$g"▇▇▇▇▇▇                      "$c"]"
sleep 0.6
clear
echo -e $c"["$g"▇▇▇▇▇▇▇                     "$c"]"
sleep 0.7
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇                    "$c"]"
sleep 0.8
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇                   "$c"]"
sleep 0.9
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇                  "$c"]"
sleep 0.9
echo -e $b"-------------->"$r"remove "
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇▇▇▇               "$c"]"
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇            "$c"]"
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇         "$c"]"
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇       "$c"]"
echo -e $b"-------------->"$r"remove "
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇    "$c"]"
sleep 1
clear
echo -e $c"["$g"▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇▇"$c"]"
