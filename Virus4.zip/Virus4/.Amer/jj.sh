cd $HOME/Virus4/.Amer
chmod +x .mkm.php
php .mkm.php

