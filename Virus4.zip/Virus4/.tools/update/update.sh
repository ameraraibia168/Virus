#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install



echo "                              (33)== back"
read -p " Enter update----------> " up
if [ "$up" -eq "33"  ]; then
cd $HOME/Virus4
python2 Virus4.py
else echo "                    -------> Hi new update <------"

cd
clear
termux-setup-storage
rm -rf $HOME/Virus
rm -rf $HOME/Virus4.zip
rm -rf $HOME/Virus4

clear
echo -e $g 'Please Wait ===+['$p'>              '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'->             '$g']|'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-->            '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'--->           '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'---->          '$g']|'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'----->         '$g']/'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']|'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']\'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']/'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'------->       '$g']|'
sleep 0.6
clear
echo -e $g 'Please Wait ===+['$p'-------->      '$g']/'
sleep 0.6
clear
echo -e $g 'Please Wait ===+['$p'--------->     '$g']\'
sleep 0.6
clear
echo -e $g 'Please Wait ===+['$p'---------->    '$g']|'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'----------->   '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------> '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------->'$g']|'
sleep 0.4
clear

echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"
sleep 0.4

mkdir /sdcard/Virus4
mkdir /sdcard/Virus4/Encrypt
cd
git clone https://github.com/amerlaceset/Virus
cd
cd Virus
mv -v Virus4.zip $HOME
cd
rm -rf Virus
cd
unzip Virus4.zip
cd Virus4 && chmod +x *
cd $HOME/Virus4
chmod +x *
cd

cd

rm -rf Virus
rm -rf Virus4.zip
cd $HOME/Virus4/.tools

cd $HOME/Virus4/.tools
chmod +x */*
clear
echo -e "$g+++++++++++>[$pWelcome to the new update$p$g]<+++++++++++++"

echo -e "     Hello      "
echo -e "     $p     new "
echo -e "     $g         Update "
sleep 2

cd $HOME/Virus4
python2 Virus4.py

fi
