clear
cd

rm -rf update.sh 

cd $HOME/Virus4/.tools/update

cp update.sh $HOME


cd
clear
bash update.sh


cd

rm -rf update.sh
