#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install
sleep 0.01
cd
clear
sleep 0.01







cd $HOME/Virus4/.tools
sleep 0.01
echo -e "$red "
sleep 0.01

echo ""
echo ""
echo -e "$green  _____  $red  _      ______      ________  $purple __     ______  _    _"
sleep 0.01
echo -e "$green |_   _| $red | |    / __ \ \    / /  ____| $purple \ \   / / __ \| |  | |"
sleep 0.01
echo -e "$green   | |   $red | |   | |  | \ \  / /| |__    $purple  \ \_/ / |  | | |  | |"
sleep 0.01
echo -e "$green   | |   $red | |   | |  | |\ \/ / |  __|   $purple   \   /| |  | | |  | |"
sleep 0.01
echo -e "$green  _| |_  $red | |___| |__| | \  /  | |____  $purple    | | | |__| | |__| |"
sleep 0.01
echo -e "$green |_____| $red |______\____/   \/   |______| $purple    |_|  \____/ \____/"
sleep 0.01

echo ""
echo ""
echo ""
sleep 0.01
echo -e "$cyan              __      ___                  _  _     "
sleep 0.01
echo -e "$purple              \ \    / (_)                | || |    "
sleep 0.01
echo -e "$green               \ \  / / _ _ __ _   _ ___  | || |_   "
sleep 0.01
echo -e "$blue                \ \/ / | | '__| | | / __| |__   _|  "
sleep 0.01
echo -e "$yellow                 \  /  | | |  | |_| \__ \    | |    "
sleep 0.01
echo -e "$reset                  \/   |_|_|   \__,_|___/    |_|    "
                 
echo ""
echo ""

sleep 0.01
echo -e "                      $blue V $green i $reset r $purple u $cyan s $yellow 4 $green ^_^"
sleep 0.01
echo -e " $blue ▇◤▔▔▔▔▔▔▔◥▇ $green ╲╲╲╲╲┏━━━━┓╱╱╱╱╱ $purple┊┊┊▕▔▔▔▔▏┊┊┊Amer┊$red ╭╮╮╱▔▔▔▔╲╭╭╮"
sleep 0.01
echo -e " $blue ▇▏◥▇◣┊◢▇◤▕▇ $green ╭┓┏╮┏┫╰╯╰╯┣┓╭┓┏╮ $purple┊┊▂▂▇▇▇▇▂▂┊┊┊DZ┊┊$red ╰╲╲▏▂╲╱▂▕╱╱╯"
sleep 0.01
echo -e " $blue ▇▏▃▆▅▎▅▆▃▕▇ $green ┃┗┛┃┗┫┗━━┛┣┛┃┗┛┃ $purple┊▕▂▂▂▂▂▂▂▂▏Amerr $red ┈┈╲▏▇▏▕▇▕╱┈┈"
sleep 0.01
echo -e " $blue ▇▏╱▔▕▎▔▔╲▕▇ $green ╰┳┳╯┏┻━━━━┻┓╰┳┳╯ $purple┊┊┏┫╭▅╭▅┣┓┊┊╭╯-- $red ┈┈╱╲▔▕▍▔╱╲┈┈"
sleep 0.01
echo -e " $blue ▇▇◣◥▅▅▅◤◢▇▇ $green ╱┣┗┳┫┈▕╲▂╱▏┣┳┛┫╲ $purple┊┊╰╮▔╭╮▔╭╯┊╭╯┊┊┊ $red ╭╱╱▕╋╋╋╋▏╲╲╮"
sleep 0.01
echo -e " $blue ▇▇▇◣╲▇╱◢▇▇▇ $green ╱╰┻┻┫┈▕▕♡▏▏┣┻┻╯╲ $purple┊┊┊╯╰━━━▃▃▃▇┊┊┊┊ $red ╰╯╯┈╲▂▂╱┈╰╰╯"
sleep 0.01
echo -e " $blue ▇▇▇▇◣▇◢▇▇▇▇ $green ╱╱╱╱┃┈▕╱▔╲▏┃╲╲╲╲ $purple╱▔▔╯╯╯╰╰╰▔▔╲┊┊┊┊ $cyan  {Hackers}"
sleep 0.01

echo -e "$red .||====$red>$blue>>>$red>$green>>>$red>$blue>>$red>$green>>$red>── $green Amer.Amerr  $red──<$green<<$red<$blue<<$red<$green<<<$red<$blue<<<$red<====||'"

sleep 0.01

echo -e "                      $blue V $green i $reset r $purple u $cyan s $yellow 4 $green ^_^"
sleep 0.01
