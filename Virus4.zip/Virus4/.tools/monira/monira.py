import random
import os
e = str(random.randint(1,7))
if e in "1":
   os.system("bash $HOME/Virus4/.tools/monira/moni1.sh")
elif e in "2":
   os.system("bash $HOME/Virus4/.tools/monira/moni2.sh")
elif e in "3":
   os.system("bash $HOME/Virus4/.tools/monira/moni3.sh")
elif e in "4":
   os.system("bash $HOME/Virus4/.tools/monira/moni4.sh")
elif e in "5":
   os.system("bash $HOME/Virus4/.tools/monira/moni5.sh")
elif e in "6":
   os.system("bash $HOME/Virus4/.tools/monira/moni6.sh")
elif e in "7":
   os.system("bash $HOME/Virus4/.tools/monira/moni7.sh")
else :
   print "error"

