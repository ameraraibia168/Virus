cd $HOME/Virus4/.tools/monira

python2 monira.py