#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install
sleep 0.01
cd
clear
sleep 0.01







cd $HOME/Virus4/.tools
sleep 0.01
echo -e "$red "
sleep 0.01

echo ""
echo ""
echo -e "$green  _____  $red  _      ______      ________  $purple __     ______  _    _"
sleep 0.01
echo -e "$green |_   _| $red | |    / __ \ \    / /  ____| $purple \ \   / / __ \| |  | |"
sleep 0.01
echo -e "$green   | |   $red | |   | |  | \ \  / /| |__    $purple  \ \_/ / |  | | |  | |"
sleep 0.01
echo -e "$green   | |   $red | |   | |  | |\ \/ / |  __|   $purple   \   /| |  | | |  | |"
sleep 0.01
echo -e "$green  _| |_  $red | |___| |__| | \  /  | |____  $purple    | | | |__| | |__| |"
sleep 0.01
echo -e "$green |_____| $red |______\____/   \/   |______| $purple    |_|  \____/ \____/"
sleep 0.01

echo ""
echo ""
echo ""

echo -e "$cyan              __      ___                  _  _     "
sleep 0.01
echo -e "$purple              \ \    / (_)                | || |    "
sleep 0.01
echo -e "$green               \ \  / / _ _ __ _   _ ___  | || |_   "
sleep 0.01
echo -e "$blue                \ \/ / | | '__| | | / __| |__   _|  "
sleep 0.01
echo -e "$yellow                 \  /  | | |  | |_| \__ \    | |    "
sleep 0.01
echo -e "$reset                  \/   |_|_|   \__,_|___/    |_|    "
                  
echo ""
echo ""

sleep 0.01
echo -e "                      $blue V $green i $reset r $purple u $cyan s $yellow 4 $green ^_^"
sleep 0.01
cd

echo -e "$cyan"
echo -e "                      _____________________"
sleep 0.01
                                
echo -e "                     ( $blue Amer $cyan ##### $red Amer $cyan )"
sleep 0.01
echo -e '                  /_~~~~~~~~~~~~~~~~~~~~~~~~~_\'
sleep 0.01
echo -e '                /~                             ~\'
sleep 0.01
echo -e '              .~             '$g'Virus4 '$cyan'             ~'
sleep 0.01
echo -e '          ()\/_____                           _____\/()'
sleep 0.01
echo -e '         .-``      ~~~~~~~~~~~~~~~~~~~~~~~~~~~     ``-.'      
sleep 0.01
echo -e '      .-~              ____'$y'I Love you'$cyan'____             ~-.'  
sleep 0.01
echo -e '      `~~/~~~~~~~~~~~~TTTTTTTTTTTTTTTTTTTT~~~~~~~~~~~~\~~`'
sleep 0.01
echo -e '      | | |'$g' #### #### '$cyan'|| | | | [] | | | || '$g'#### ####'$cyan' | | |'  
sleep 0.01
echo -e '      ;__\|___________|++++++++++++++++++|___________|/__;'
sleep 0.01
echo -e '       (~~====___________________________________====~~~)'
sleep 0.01
echo -e '        \------_____________[Amer DZZ]__________-------/'
                                        
sleep 0.01
echo -e '           |      ||         ~~~~~~~~       ||      |'
sleep 0.01
echo -e '            \_____/                          \_____/'

        
sleep 0.01

echo -e "$red .||====$red>$blue>>>$red>$green>>>$red>$blue>>$red>$green>>$red>── $green Amer.Amerr  $red──<$green<<$red<$blue<<$red<$green<<<$red<$blue<<<$red<====||'"

sleep 0.01

echo -e "                      $blue V $green i $reset r $purple u $cyan s $yellow 4 $green ^_^"
sleep 0.01
