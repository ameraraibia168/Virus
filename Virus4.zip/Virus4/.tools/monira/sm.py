import os

                                                
print ('''            `://-::.`                          `-++syhs` ''')

os.system('sleep 0.01')
print ('''            dNNNNNNNds-                      `odNNmddmm`              ''')

os.system('sleep 0.01')
print ('''            /mmmmdddmNdo-                   :hmdhhddmN+               ''')

os.system('sleep 0.01')
print ('''             /Nmmdddhhho++`     Virus4     /hdhhhhhhdm-               ''')


os.system('sleep 0.01')
print ('''              hmdhhhyho/s/o.              /ddhhyyyyyhm:               ''')
os.system('sleep 0.01')

print ('''              omdyyyso/.-s/s.            .hhdyyyysssyho               ''')

os.system('sleep 0.01')
print ('''              omdyyyys+-..o/s```..```.``.oddyyo+/:://oo`              ''')
os.system('sleep 0.01')

print ('''              /mddysss+::-.+y/``..``...`.ymhhho/:.-/+s/`              ''')

os.system('sleep 0.01')
print ('''              `+ddyyss/---.`sh.``-``...`.hdyyhssss+::::/++:`          ''')

os.system('sleep 0.01')
print ('''            -+syyyyyyy:oo:..-y: `````..``dsyyyyhhh/--:+sdNNm:         ''')
os.system('sleep 0.01')

print ('''          .smmdhysosyy.-:...-+y//``  ``:-mdhhhyyysoshddmmNNNN/        ''')
os.system('sleep 0.01')
print ('''          ymmdsyyyssso/::-:/+yNd/`     /dNNdyhhhhhshdmmmmmNMMm`       ''')
os.system('sleep 0.01')
print ('''         +mmmhosyyyys::+shdmNNd:`.-    ::sdddhddddhhdmmmmmNMN/        ''')
os.system('sleep 0.01')
print ('''         oNmmhyyyyhdhhhdhhs/+---``-` ``/.`-.:`:+odh+sydmNMNy-         ''')
os.system('sleep 0.01')

print ('''       ``.+mmmmddmmdysmh//-.:--.:.-....:-.---..........:+/-`          ''')
os.system('sleep 0.01')
print ('''         ..-ohNNNho::://::://+////::::::::::::-----.......``       ''')
os.system('sleep 0.01')

print ('''          `...---------:::::::::::::------------.......````           ''')
os.system('sleep 0.01')
print ('''             `````````````...........```````````````````              ''')
os.system('sleep 0.01')                                                     
                    
