import os


print ('''                            `...-........`                   ''')
os.system('sleep 0.01')


print ('''                       `-:/::::--------:///-                ''')
os.system('sleep 0.01')
print ('''                     .//::::--...```.....--/o:`             ''')
os.system('sleep 0.01')

print ('''                   `:+/::::--.`         ``..:oo-            ''')
os.system('sleep 0.01')

print ('''                  `/+////:--.`             `.-+y/           ''')
os.system('sleep 0.01')
print ('''                  :+///+/:--..`             `.:+y/          ''')

os.system('sleep 0.01')
print ('''                 -+///o+::::--...``         ``-:oy-         ''')
os.system('sleep 0.01')

print ('''                `/+/+/oo/:-----::::-.`      ``.:+ys         ''')
os.system('sleep 0.01')
print ('''  -/....        .+o+s/o:.``  `.----//:-``````.::+yy         ''')
os.system('sleep 0.01')
print ('''  :+so:`.       .ossh++:.``     `.:--/o/:----:::+ys         ''')
os.system('sleep 0.01')
print ('''  `/so.``       `oyhdyosys+:``    .//:/soo++//::sy:         ''')
os.system('sleep 0.01')

print ('''  -o//:.`.       `ydy+/-sNdo+:.`  `.s+-/yhyyo+:ohy.         ''')
os.system('sleep 0.01')

print (''' `///sys:```      -+++-`sd-./+o/-` `/s/-oo/::::-.:y+        ''')

os.system('sleep 0.01')
print ('''   `````:+-`.`    `:/s/.`//:/:/hy/.`-syo+-..`````/s+        ''')
os.system('sleep 0.01')
print ('''         `:+.`.`   `-/++.`-/oshdsoyyyysh/-+shmmo/-`         ''')

os.system('sleep 0.01')
print ('''           `+/`.-`  :y++s+:.`.``.:yh+yhomNNNMm/+            ''')
os.system('sleep 0.01')
print ('''             -+:`-:-s+:oh++/+++osyoyyhmsysyys-o/       .::.  ''')

os.system('sleep 0.01')
print ('''              `/o.`/+:+/ho://://+o/o+oyo+--///-       /y/.:. ''')


os.system('sleep 0.01')
print ('''                .+/.:+s+::o++-/::/://+++o:`        `-+o:`-- ''')
os.system('sleep 0.01')

print ('''                  -o/+o++-/Nd/::.-.-:::+/    `.-::::-```.s- ''')
os.system('sleep 0.01')

print ('''                   `+ho+/:-dMNMNy:/y+/::`.-:::-```......./: ''')
os.system('sleep 0.01')

print ('''                     .o++/:/dNmmm/:++::::.``......`         ''')

os.system('sleep 0.01')

print ('''                       /++/::::++/+/-.`.--..`               ''')

os.system('sleep 0.01')
print ('''                       `+s+/+/:/+s-::--`                    ''')

os.system('sleep 0.01')
print ('''                   `.:///oyo+++//+`                         ''')

os.system('sleep 0.01')
print ('''               .-:::-..-:++---://-:`                        ''')
os.system('sleep 0.01')
print ('''          `-:::-``----.`      `:o:`--`                      ''')
os.system('sleep 0.01')
print ('''  `....-:/:-``---.`             `:+:.-.                     ''')
os.system('sleep 0.01')
print (''' --`..-..``--.`                   `-+-.-.                   ''')
os.system('sleep 0.01')
print ('''`+/:/:```-.           Virus4        `:/..:-`                ''')
os.system('sleep 0.01')
print ('''   `/y- -`           AmerrDzz         `/+/.....-            ''')
os.system('sleep 0.01')
print ('''    `++:.                               +o```-::            ''')
os.system('sleep 0.01')
print ('''                                        `+/:/-              ''')
os.system('sleep 0.01')
