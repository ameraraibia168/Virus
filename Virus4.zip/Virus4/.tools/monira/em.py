import os
print ('''                                       .-.              ''')

os.system('sleep 0.01')
print ('''                                       : `-`        ''')
os.system('sleep 0.01')


print ('''                                     -o. .:/-           ''')                                  
os.system('sleep 0.01')

print ('''                                     -o   ``:/              ''')           


os.system('sleep 0.01')

print ('''                                    .++      .:             ''')
os.system('sleep 0.01')


print ('''                                     ./       .-.               ''')                           

os.system('sleep 0.01')


print ('''                           Virus4     o..   .  /- -                                     ''')
os.system('sleep 0.01')


                                           

print ('''                        `.`..-:-`    .sh+-.`:- :`:.                                        ''')


os.system('sleep 0.01')
print ('''                        hshmmmdddhhdmNmooyhhh+:o/:-                         ''')



os.system('sleep 0.01')
print ('''                       `+smmNmNNmmmNNNdyyhddmNd+.                      ''')

os.system('sleep 0.01')
print ('''                         .dmmmNNmmmNNNhyyhddddh.                          ''')
os.system('sleep 0.01')

print ('''                         `hmmhdNmmmNNMmdssshNdy`                                           ''')

os.system('sleep 0.01')
print ('''                        -dyh:  .//+/sNmso+-+Ndy+                                               ''')
os.system('sleep 0.01')
print ('''                         s/s.        dy+s  `:::`                                             ''')

os.system('sleep 0.01')

print ('''                         -so/.`      h/o:                                                         ''')
os.system('sleep 0.01')
print ('''                         `hsoys` `   s-y/`                                                   ''')
os.system('sleep 0.01')
print ('''                          -hdh/`````.h:shh+`````                                             ''')


os.system('sleep 0.01')

print ('''                        ``.--.``````.Ndh:-.`````````````        ''')
os.system('sleep 0.01')


print ('''                     `````..`````````:/:.```````````````````                                ''')
os.system('sleep 0.01')

print ('''                `````````....````````.`..```````````````````                                  ''')
os.system('sleep 0.01')


print ('''               ``````````......``````-`..```````````````````````                            ''')



os.system('sleep 0.01')
print ('''        ``````````````````...........-...`````````````````````````````````                   ''')
os.system('sleep 0.01')
print ('''````````````````````````....----.....--...````````````````````````````````                      ''')
os.system('sleep 0.01')
print ('''````````````````````````.........-------....``````````````````````````````                     ''')

os.system('sleep 0.01')
print ('''``````````````````````````........------......`````````````````````````````     ''')

os.system('sleep 0.01')
print ('''````````````````````````````.........---.......````````````````````````````       ''')
os.system('sleep 0.01')
print ('''````````````````````````````....................```````````````````````````   ''')

os.system('sleep 0.01')
print ('''````````````````````````........................``````````````````````````` ''')

os.system('sleep 0.01')
print ('''................````...............................```````````````````````''')   
os.system('sleep 0.01')


print ('''................................................................```````''')    
os.system('sleep 0.01')


print ('''.........Github : https://github.com/Amerlaceset...............................''') 

os.system('sleep 0.01')

print ('''........................ Amer Dzz { Virus4 } .............................''')         
os.system('sleep 0.01')


print ('''.....................................................................      ''')
os.system('sleep 0.01')                              
