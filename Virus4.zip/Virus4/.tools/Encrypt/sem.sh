g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
 
sleep 0.1
echo -e "$red                                          [0]back"
echo -e "$blue"

sleep 0.1

echo "      [1]google.com"
sleep 0.1
echo "      [2]altenen.nz"
sleep 0.1
echo ""
sleep 0.1
echo -e "$green"
sleep 0.1
