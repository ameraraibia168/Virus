pkg install list-all

pkg install w3m

w3m google.com



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
