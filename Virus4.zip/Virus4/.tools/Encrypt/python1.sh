pkg install list-all

pkg install w3m

w3m google.com

