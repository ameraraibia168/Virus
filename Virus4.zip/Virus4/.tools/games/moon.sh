apt-get install moon-buggy

pkg install moon-buggy

moon-buggy



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
