apt-get install moon-buggy

pkg install moon-buggy

moon-buggy



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
