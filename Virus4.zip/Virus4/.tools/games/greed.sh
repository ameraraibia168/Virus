apt-get install greed


greed
