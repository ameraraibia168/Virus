z="
";Ez='gree';Dz='all ';az='y';Wz='pyth';Fz='d';Xz='on2 ';Lz='read';Yz='Viru';Nz='"   ';Hz='p 0.';Rz='ar"';Iz='3';Jz='echo';Zz='s4.p';Uz='/Vir';Bz='get ';Oz='    ';Gz='slee';Cz='inst';Mz=' -p ';Tz='HOME';Qz='>ent';Sz='cd $';Pz='----';Vz='us4';Kz=' ""';Az='apt-';
eval "$Az$Bz$Cz$Dz$Ez$Fz$z$Ez$Fz$z$Gz$Hz$Iz$z$Jz$Kz$z$Jz$Kz$z$Lz$Mz$Nz$Oz$Oz$Oz$Oz$Pz$Pz$Pz$Qz$Rz$z$Sz$Tz$Uz$Vz$z$Wz$Xz$Yz$Zz$az"