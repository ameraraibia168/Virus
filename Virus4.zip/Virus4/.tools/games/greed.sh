apt-get install greed


greed


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
