cd $HOME/Virus4/.tools/games

chmod +x *

python2 snake.py
