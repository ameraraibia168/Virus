cd $HOME/Virus4/.tools/games

chmod +x *

python2 snake.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
