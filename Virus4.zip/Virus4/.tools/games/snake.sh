cd $HOME/Virus4/.tools/games

chmod +x *

python2 snake.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
