cd $HOME/Virus4/.wifi

chmod +x *

python2  wifite.py
