cd $HOME/Virus4/.wifi

chmod +x *

python2  wifite.py

sudo ./wifite.py
sudo python2 wifite.py
sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
