cd

apt update

apt upgrade

pkg install git 

pkg install nucurses-utils

pkg install tsu

git clone https://github.com/st42/termux-sudo.git

cd termux-sudo


cat sudo > /datd/data/com.termux/files/usr/bin/


chmod 700 /datd/data/com.termux/files/usr/bin/sudo


chmod +x * /datd/data/com.termux/files/usr/bin/sudo


sudo su




sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
