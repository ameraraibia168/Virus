cd $HOME/Virus4/.wifi/wifite2

chmod +x *

python2 Wifite.py

sudo ./Wifite.py

sudo python2 Wifite.py

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
