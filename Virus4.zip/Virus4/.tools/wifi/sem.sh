#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install

echo -e "      $red                                    [0]back"
echo -e "$cyan"
echo "           [1]open wifite "
echo "           [2]open wifite2 "
echo "           [3]install sudo "
echo -e "$green"

