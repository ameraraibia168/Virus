apt $n  nmap -y
clear
nmap -sn 192.168.1.1/24
read -p "                        ---------->entar"
Virus4.sh

