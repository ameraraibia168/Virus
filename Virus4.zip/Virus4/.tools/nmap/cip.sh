read -p "            ip-------->" ip
apt $n  nmap -y
clear
nmap $ip
sleep 3
read -p "                   ------------>entar"
Virus4.sh

