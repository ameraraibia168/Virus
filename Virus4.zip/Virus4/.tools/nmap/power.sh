read -p "            ip-------->" ip
read -p "          port-------->" p
apt $n  nmap -y
clear
nmap -sA -p $p $ip
sleep 3
read -p "                   ------------>entar"
Virus4.sh


