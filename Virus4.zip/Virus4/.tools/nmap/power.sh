read -p "            ip-------->" ip
read -p "          port-------->" p
apt $n  nmap -y
clear
nmap -sA -p $p $ip
sleep 3
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
