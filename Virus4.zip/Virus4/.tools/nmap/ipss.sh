read -p "            ip-------->" ip
apt $n  nmap -y
clear
nmap -O $ip
sleep 3
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
