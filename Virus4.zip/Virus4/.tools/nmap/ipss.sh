read -p "            ip-------->" ip
apt $n  nmap -y
clear
nmap -O $ip
sleep 3
read -p "                   ------------>entar"
Virus4.sh
