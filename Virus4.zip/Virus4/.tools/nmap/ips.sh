cd
python2 $HOME/Virus4/.max/zz.py
