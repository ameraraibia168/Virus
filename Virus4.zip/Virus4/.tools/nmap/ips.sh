cd
python2 $HOME/Virus4/.Amer/zz.py


