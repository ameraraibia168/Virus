clear
cd
pip2 install mechanize
cd $HOME/Virus4/.max
clear
python2 op.py
