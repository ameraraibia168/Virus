clear
cd
pip2 install mechanize
cd $HOME/Virus4/.max
clear
python2 op.py

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
