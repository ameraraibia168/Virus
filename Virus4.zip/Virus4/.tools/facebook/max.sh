clear
cd
pip2 install mechanize
cd $HOME/Virus4/.max
clear
python2 op.py
sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
