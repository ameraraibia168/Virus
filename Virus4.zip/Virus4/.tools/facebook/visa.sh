cd $HOME/Virus4/.tools/facebook/ccgen/es_MX

chmod +x *
./ccgen.py

./ccgen.py -b 548732xxxxxxxxxx -u 100 -d -c

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
