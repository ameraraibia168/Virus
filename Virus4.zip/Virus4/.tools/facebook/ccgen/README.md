# CCGen
Generador de tarjetas de credito con check incluido.

## Disclaimer
This repository is for academic purposes, the use of this software is your
responsibility.

Este repositorio esta hecho con fines educativos, el uso de este software es tu
responsabilidad.
