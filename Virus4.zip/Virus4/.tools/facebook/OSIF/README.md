
# this project will be stopped for some time to come.

```
                                          _     _
                                        o' \.=./ `o
                                           (o o)          
                                       ooO--(_)--Ooo
                                       
                                          O S I F
                            [open source information facebook]
```
OSIF is an accurate facebook account information gathering, all sensitive information can be easily gathered even though the target converts all of its privacy to (only me), Sensitive information about residence, date of birth, occupation, phone number and email address.



# [ Installation ]
```
$ pkg update upgrade
$ pkg install git python2
$ git clone https://github.com/ciku370/OSIF
$ cd OSIF
```

# [ Setup ]
```
$ pip2 install -r requirements.txt
```
# [ Running ]
```
$ python2 osif.py
```
# [ Screenshot ]
<img src=".images/osif.png "/>

* if you are confused how to use it, please type 'help' to display the help menu
* [Warn] please turn off your VPN before using this program !!!
* [Tips] do not overuse this program !!!
