cd $HOME/Virus4/.tools/facebook/guardn


pkg install pip

pkg install pip2

pip install --upgrade pip


pip install requests


chmod +x guardn.py

clear

python3 guardn.py





sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
