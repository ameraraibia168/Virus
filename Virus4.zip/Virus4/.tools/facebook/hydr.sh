cd $HOME/Virus4/.tools/facebook/Black-Hydra

chmod +x *

python2 blackhydra.py

sleep 0.3
echo ""

echo ""
read -p "                   ------------>entar"
Virus4.sh
