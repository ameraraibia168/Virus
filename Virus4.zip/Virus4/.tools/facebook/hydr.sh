cd $HOME/Virus4/.tools/facebook/Black-Hydra

chmod +x *

python2 blackhydra.py
