#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'



echo -e "  $red         [1]add password        [0]back"
echo ""
echo -e " $green      id = E-mail "
echo "               password = password.txt "
read -p "            entat   " amerr
if [ "$ali" -eq "1"  ]; then
nano $HOME/Virus4/.facebook/password.txt
cd $HOME/Virus4
python2 Virus4.py
elif [ "$amerr" -eq "0" ]; then
cd $HOME/Virus4
python2 Virus4.py
else
cd
pip2 install mechanize
clear
sh $HOME/Virus4/.cxcxcx.sh
echo -e " $yellow                 password = password.txt"
echo -e "$green"
cd $HOME/Virus4/.facebook
rm -rf password.txt
git clone https://github.com/Amerlaceset/facebook
mv facebook/password.txt $HOME/Virus4/.facebook
rm -rf facebook
python2 $HOME/Virus4/.facebook/facebook.py
sleep 1000000
fi

