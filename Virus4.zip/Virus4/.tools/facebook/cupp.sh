cd $HOME/Virus4/.tools/facebook/cupp

python cupp.py -i


sleep 0.3
cd $HOME/Virus4/.tools/facebook/cupp


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
