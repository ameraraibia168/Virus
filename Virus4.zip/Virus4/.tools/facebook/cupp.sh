cd $HOME/Virus4/.tools/facebook/cupp

python cupp.py -i
