
read -p "  Entre name The LisT : -------> " list
sleep 0.3
cd $HOME/Virus4/.tools/facebook

python Goodlist.py


cd $HOME/Virus4/.tools/facebook

mv -v $list /sdcard/Virus4

echo ""
echo ""

read -p "       Wordlist on /sdcard/Virus4"
cd $HOME/Virus4
python2 Virus4.py
