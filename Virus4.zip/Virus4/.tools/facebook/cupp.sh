cd $HOME/Virus4/.tools/facebook/cupp

python cupp.py -i


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
