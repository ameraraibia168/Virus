g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install

 
echo -e "   $red                                       [0]back"
echo -e "$purple"
echo "         [1]Guess facebook 1"
echo "         [2]Available facebook"
echo "         [3]A fake page for Facebook"
echo "         [4]get data osif "
echo "         [5]Enable Facebook profile picture guard"
echo "         [6]GENERATE TARGETED WORDLIST (cupp)"
echo "         [7]Guess facebook 2"
echo "         [8]Hack Mail  "
echo -e "$green"
