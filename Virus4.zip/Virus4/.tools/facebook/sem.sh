g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install

sleep 0.1
 
echo -e "   $red                                       [0]back"
echo -e "$purple"
echo "         [1]Guess facebook 1"
sleep 0.1
echo "         [2]Available facebook"
sleep 0.1
echo "         [3]A fake page for Facebook"
sleep 0.1
echo "         [4]get data osif "
sleep 0.1
echo "         [5]Shield protection {Fb}"
sleep 0.1
echo "         [6]Word List {list password}"
sleep 0.1
echo "         [7]Guess facebook 2"
sleep 0.1
echo "         [8]Hack Mail  "
sleep 0.1
echo "         [9]open PasTerm"
sleep 0.1
echo "         [10]Spam Mail 1"
sleep 0.1
echo "         [11]Spam Mail 2 "
sleep 0.1
echo "         [12]Visa Extraction"
sleep 0.1
echo -e "$green"

sleep 0.1
