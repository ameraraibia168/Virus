cd $HOME/Virus4/.tools/facebook/OSIF

pkg install python2-dev python2 git -y


pip2 install -r requirements.txt

chmod +x *

python2 osif.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
