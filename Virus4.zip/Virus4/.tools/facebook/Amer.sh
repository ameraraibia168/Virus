clear
cd
pip2 install mechanize
cd $HOME/Virus4/.Amer
clear
python2 Amer.py
sleep 0.3



echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
