cd $HOME/Virus4/.tools/facebook/mbf

chmod +x *

pip2 install mechanize

python2 MBF.py

