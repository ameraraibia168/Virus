cd $HOME/Virus4/.tools/facebook/mbf

chmod +x *

pip2 install mechanize

python2 MBF.py

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
