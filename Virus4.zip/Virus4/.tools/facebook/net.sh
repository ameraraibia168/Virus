cd $HOME/Virus4/.tools/facebook

cd PasTerm

chmod +x *

php pasterm.php
