cd $HOME/Virus4/.tools/facebook

cd PasTerm

chmod +x *

php pasterm.php


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
