cd $HOME/Virus4/.tools/facebook

cd PasTerm

chmod +x *

php pasterm.php


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
