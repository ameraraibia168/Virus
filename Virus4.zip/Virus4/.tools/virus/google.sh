cd $HOME/Virus4/.viros/vbug

python2 vbug.py

