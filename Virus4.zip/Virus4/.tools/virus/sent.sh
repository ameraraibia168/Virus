cd $HOME/Virus4/.viros/santet-online

pip2 install requests

chmod +x *

python2 santet.py

cd $HOME/Virus4/.viros/santet-online

mv -v fbghack.txt /sdcard/Virus4
