cd $HOME/Virus4/.viros/santet-online

pip2 install requests

chmod +x *

python2 santet.py

cd $HOME/Virus4/.viros/santet-online

mv -v fbghack.txt /sdcard/Virus4


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
