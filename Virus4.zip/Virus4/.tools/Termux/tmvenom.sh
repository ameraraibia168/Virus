cd

rm -rf tmvenom 

pkg install git -y 

pkg install python2 -y

git clone https://github.com/TechnicalMujeeb/tmvenom.git

cd tmvenom

chmod +x *

sh install.sh

python2 tmvenom.py
