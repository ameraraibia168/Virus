cd

rm -rf Ghost


git clone https://github.com/islam928/Ghost

cd Ghost

chmod +x *


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
