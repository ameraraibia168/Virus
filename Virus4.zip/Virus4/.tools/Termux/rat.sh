cd

rm -rf A-Rat

pkg install git -y 


git clone https://github.com/Xi4u7/A-Rat.git

ls



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
