cd

pkg install python python2 curl wget git -y 


rm -rf mbf 

cd

git clone https://github.com/YukersCreew/mbf


cd mbf

chmod +x *

pip2 install mechanize

python2 MBF.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
