pkg update -y
pkg upgrade -y
pkg install python -y
pkg install python2 -y
pkg install python3 -y
pkg install java -y
pkg install fish -y
pkg install ruby -y
pkg install help -y
pkg install git -y
pkg install host -y
pkg install php -y
pkg install perl -y
pkg install nmap -y
pkg install bash -y
pkg install clang -y
pkg install nano -y
pkg install w3m -y
pkg install havij -y
pkg install hydra -y
pkg install figlet -y
pkg install cowsay -y
pkg install curl -y
pkg install tar -y
pkg install zip -y
pkg install unzip -y
pkg install tor -y
pkg install google -y
pkg install sudo -y
pkg install wget -y
pkg install wireshark -y
pkg install wgetrc -y
pkg install wcalc -y
pkg install bmon -y
pkg install vpn -y
pkg install unrar -y
pkg install toilet -y
pkg install proot -y
pkg install net-tools -y
pkg install golang -y
pkg install chroot -y
pkg install termux-chroot -y
pkg install macchanger -y
pkg install openssl -y
pkg install cmatrix -y
pkg install openssh -y
pkg install wireshark -y
termux-setup-storage -y
pkg install macchanger -y
apt update && apt upgrade -y

cmatrix

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
