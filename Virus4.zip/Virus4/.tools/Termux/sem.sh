#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install




sleep 0.1
 
echo -e "      $red                                    [0]back"
sleep 0.1

echo -e "$reset"
sleep 0.1
echo "             [1]Change the shape of Termux📟"
sleep 0.1
echo "             [2]The shape of the skull Termux📟"
sleep 0.1
echo "             [3]The shape of the skull(2) Termux📟"
sleep 0.1
echo -e "$green"
sleep 0.1

