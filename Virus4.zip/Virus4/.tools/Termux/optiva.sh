cd

rm -rf Optiva-Framework


pkg update -y

pkg upgrade -y

pkg install python -y

pkg install python2 -y

pkg install git -y

git clone https://github.com/joker25000/Optiva-Framework

chmod 777 installer.sh

bash installer.sh

chmod 777 optiva.py

python2 optiva.py

