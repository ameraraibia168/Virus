cd

rm -rf D-TECT

apt update && apt upgrade

apt install git 

apt install python2

git clone https://github.com/shawarkhanethicalhacker/D-TECT

cd D-TECT

chmod +x *

pip2 install requests

usage :

python2 d-tect.py

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
