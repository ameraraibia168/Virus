cd

rm -rf ccgen

pkg install git

git clone https://github.com/kuurtb/ccgen.git

ls

cd ccgen

cd es_MX

./ccgen.py.
