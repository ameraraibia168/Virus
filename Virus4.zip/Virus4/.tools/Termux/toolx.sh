cd
rm -rif Tool-X
git clone https://github.com/Rajkumrdusad/Tool-X
cd Tool-X
chmod +x install.aex
./install.aex
