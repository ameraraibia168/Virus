cd

rm -rf Striker

pkg install git -y

git clone https://github.com/UltimateHackers/Striker

cd Striker

pip install -r requirements.txt

python striker.py


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
