read -p "            name-------> " amer
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/max/$amer/" $HOME/Virus4/.max/PROVE-TM > $HOME/.bashrc
pkg install figlet

cd $HOME/Virus4
python2 Virus4.py
