cd 

rm -rf NetflixChk

git clone https://github.com/juni0r007/NetflixChk

cd NetflixChk

chmod +x *

php netflixchk.php


