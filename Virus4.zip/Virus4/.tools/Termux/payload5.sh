cd

git clone https://github.com/Amerlaceset/Amerl7nanch

cd Amerl7nanch

chmod +x *

bash gta.sh


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
