cd

git clone https://github.com/Amerlaceset/Amerl7nanch

cd Amerl7nanch

chmod +x *

bash gta.sh

