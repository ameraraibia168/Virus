cd

rm -rf routersploit

apt update 

apt upgrade

apt install python

apt install python2

$ git clone https://github.com/reverse-shell/routersploit.git

cd routersploit

pip2 install -r requirments-dev.txt

pip2 install -r requirments.txt

pip2 install request

pip2 install requestsl

python2 rsf.py


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
