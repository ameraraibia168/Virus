
cd 

rm -rf termux-ohmyzsh


git clone https://github.com/Cabbagec/termux-ohmyzsh


cd termux-ohmyzsh


chmod +x *

sh install.sh


echo -e "sh install.sh"

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
