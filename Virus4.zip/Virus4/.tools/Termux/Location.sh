cd

rm -rf IPGeoLocation

apt update && apt upgrade

apt install git 

apt install python

$ git clone https://github.com/maldevel/IPGeoLocation

cd IPGeoLocation

chmod +x *

pip install -r requirements.txt


python ipgeolocation.py -t [target ip]
