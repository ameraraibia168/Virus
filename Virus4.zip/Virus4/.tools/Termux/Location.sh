cd

rm -rf IPGeoLocation

apt update && apt upgrade

apt install git 

apt install python

$ git clone https://github.com/maldevel/IPGeoLocation

cd IPGeoLocation

chmod +x *

pip install -r requirements.txt


python ipgeolocation.py -t [target ip]


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
