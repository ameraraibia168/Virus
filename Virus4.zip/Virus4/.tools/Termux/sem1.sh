read -p "            name-------> " amer
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/Sniper/$amer/" $HOME/Virus4/.bashrc > $HOME/.bashrc
pkg install figlet

cd $HOME/Virus4
python2 Virus4.py

