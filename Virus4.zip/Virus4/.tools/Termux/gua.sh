cd

rm -rf guardn

pkg install git -y

git clone https://github.com/Noxturnix/guardn


cd guardn
pip install requests
chmod +x guardn.py


python3 guardn.py

