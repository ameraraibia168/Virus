colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
 
echo -e " $blue "
figlet -f big " DORK"
echo -e " $red Amer Dz  "
echo -e "$green ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓"
echo -e "$cyan "
echo "page.php?id="

echo "trainers.php?id="

echo "article.php?ID="

echo "games.php?id="

echo "newsDetail.php?id="

echo "staff.php?id="

echo "products.php?id="

echo "news_view.php?id="

echo "opinions.php?id="

echo "pages.php?id="

echo "prod_detail.php?id="
cd $HOME/Virus4/.tools/website
python dork.py

echo -e "$red I LOVE YOU $green MY FRINDES $cyan  IAM ($blue Amer Dz $cyan)"
read -p "                              ------->entar<------"
cd $HOME/Virus4
python2 Virus4.py
