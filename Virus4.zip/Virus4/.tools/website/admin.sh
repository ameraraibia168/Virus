cd $HOME/Virus4/.tools/admin/admin-panel-finder

python2 admin_panel_finder.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
