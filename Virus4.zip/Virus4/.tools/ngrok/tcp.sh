echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
cd $HOME/Virus4
python2 Virus4.py
else
cd && ./ngrok tcp $port
fi

