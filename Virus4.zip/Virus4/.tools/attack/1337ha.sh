cd $HOME/Virus4/.tools/password/1337Hash

python2 1337hash.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
