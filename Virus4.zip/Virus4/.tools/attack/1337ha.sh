cd $HOME/Virus4/.tools/password/1337Hash

python2 1337hash.py

