cd $HOME/Virus4/.tools/admin/admin-panel-finder

python2 admin_panel_finder.py

