cd $HOME/Virus4/.tools/attack/

cd SQLShark

chmod +x setup.sh

sh setup.sh

shark

./shark



