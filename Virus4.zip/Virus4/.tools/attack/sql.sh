cd $HOME/Virus4/.tools/attack/

cd SQLShark

chmod +x setup.sh

sh setup.sh

shark

./shark





sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
