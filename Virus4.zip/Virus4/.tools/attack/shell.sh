cd $HOME/Virus4/.tools/password/Xshell/

python xshell.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
