cd $HOME/Virus4/.tools/password/Xshell/

python xshell.py

