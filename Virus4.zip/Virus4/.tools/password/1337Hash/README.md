# 1337Hash

### Description
The 1337Hash is a hash tool for hash a text and crack a hash

#### Requirements
• Python 2.7

#### Installation and Using 1337Hash
• sudo su<br />
• git clone https://github.com/Gameye98/1337Hash.git<br />
• cd 1337Hash/src<br />
• python 1337hash.py


