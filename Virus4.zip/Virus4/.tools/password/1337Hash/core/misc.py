## misc.py - Useful module of 1337Hash
# -*- coding: utf-8 -*-
##
import os
import sys

__banner__ = """
\033[1;31m ___    ___  ___  ___ \033[1;33m  _____            _   \033[0m
\033[1;31m|_  |  |_  ||_  ||_  |\033[1;33m |  |  | ___  ___ | |_ \033[0m
\033[1;31m _| |_ |_  ||_  |  | |\033[1;33m |     || .'||_ -||   |\033[0m
\033[1;37m|_____||___||___|  |_|\033[1;33m |__|__||__,||___||_|_|\033[0m
"""

def leethash_banner():
	print __banner__

def clearscreen():
	if sys.platform == "linux2":
		os.system("clear")
	elif sys.platform == "win32":
		os.system("cls")
	else:
		os.system("clear")