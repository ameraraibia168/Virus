cd
pkg install unstable-repo

pkg install metasploit



cd metasploit-framework
bundle update nokogiri




sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
