echo -e "++++++++++++++++> please wait <++++++++++++++++"
cd 
cd Virus4
cd .msf
chmod +x *
sh .error.sh
