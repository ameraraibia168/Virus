rm -rf $HOME/metasploit-framework
rm -rf $HOME/metasploit.sh
cp $HOME/Virus4/.metasploit.sh $HOME/metasploit.sh
cd
chmod +x $HOME/metasploit.sh
sh $HOME/metasploit.sh
