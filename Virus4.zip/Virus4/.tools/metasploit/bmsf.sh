z="
";Fz='oit-';Sz='d +x';Gz='fram';Rz='chmo';Xz='t.sh';Uz='ME/m';Cz='HOME';Wz='ploi';Nz='us4/';Bz='rf $';Pz='sh $';Kz='sh';Ez='aspl';Tz=' $HO';Vz='etas';Mz='/Vir';Qz='cd';Lz='cp $';Hz='ewor';Az='rm -';Dz='/met';Oz='.met';Jz='oit.';Iz='k';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$z$Az$Bz$Cz$Dz$Ez$Jz$Kz$z$Lz$Cz$Mz$Nz$Oz$Ez$Jz$Pz$Cz$Dz$Ez$Jz$Kz$z$Qz$z$Rz$Sz$Tz$Uz$Vz$Wz$Xz$z$Pz$Cz$Dz$Ez$Jz$Kz"