#-------------------------------------------------
#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install

sleep 0.1



echo -e "$red                                          [0]back"
sleep 0.1
echo -e "$cyan"   
sleep 0.1
echo "            [1]payload  android💉📲"
sleep 0.1
echo "            [2]payload  Mac    💉📲"
sleep 0.1
echo "            [3]payload  windows💉💻"
sleep 0.1
echo "            [4]payload  Linux  💉💻"
sleep 0.1
echo "            [5]payload  python 💉💻"
sleep 0.1
echo "            [6]payload  bash   💉💻"
sleep 0.1
echo "            [7]payload  perl   💉💻"
sleep 0.1
echo "            [8]Android  penetration msf 📟📲"
sleep 0.1
echo "            [9]Mac      penetration msf 📟📲"
sleep 0.1
echo "            [10]windows penetration msf 📟💻"
sleep 0.1
echo "            [11]Linux   penetration msf 📟💻"
sleep 0.1
echo "            [12]python  penetration msf 📟💻"
sleep 0.1
echo "            [13]bash    penetration msf 📟💻"
sleep 0.1
echo "            [14]perl    penetration msf 📟💻"
sleep 0.1
echo "            [15]URL     penetration msf 📟💻"
sleep 0.1
echo "            [16]Breakthrough via Port (21)💉"
sleep 0.1
echo "            [17]reakthrough via Port (445)💉"
sleep 0.2
echo "            [18]Open (sms,calllog,....txt) The victim 📞📩   "
sleep 0.2
echo "            [19]Open the victim files that you downloaded 📁 "
sleep 0.2
echo "            [20]Download msf ⬇️"
sleep 0.2
echo "            [21]Download msf (5.0.0)⬇️"
sleep 0.2
echo "            [22]Install msf without problems ⬇️"
sleep 0.3
echo "            [23]error metasploit ⚠️             "
sleep 0.3
echo -e "$green"
sleep 0.3
