#-------------------------------------------------
#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install



 

echo -e "$red                                          [0]back"
echo -e "$cyan"
echo "            [1]payload android 💉📲"
echo "            [2]payload windows 💉💻"
echo "            [3]Android penetration msf 📟📲"
echo "            [4]windows penetration msf 📟💻"
echo "            [5]Breakthrough via Port (21)💉"
echo "            [6]Breakthrough via Port (445)💉"
echo "            [7]open (sms,calllog,....txt) The victim 📞📩   "
echo "            [8]Open the victim files that you downloaded 📁 "
echo "            [9]Download msf ⬇️"
echo "            [10]error metasploit ⚠️             "
echo "            [11]Download msf (5.0.0)⬇️"
echo "            [12]Install msf without problems "
echo -e "$green"
