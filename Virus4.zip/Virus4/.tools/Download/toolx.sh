cd
rm -rif Tool-X
git clone https://github.com/Rajkumrdusad/Tool-X
cd Tool-X
chmod +x install.aex
./install.aex


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
