cd

rm -rf Email-bomber

pkg install git

git clone https://github.com/zanyarjamal/Email-bomber


ls

cd Email-bomber

chmod 777 E-bomber.py

python2 E-bomber.py


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
