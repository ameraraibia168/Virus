cd

rm -rf SocialFish

apt update 

apt upgrade

apt install git

apt install python2

git clone https://github.com/UndeadSec/SocialFish.git

cd SocialFish

chmod +x *

pip2 install -r requirements.txt

python2 SocialFish.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
