cd 

rm -rf NetflixChk

git clone https://github.com/juni0r007/NetflixChk

cd NetflixChk

chmod +x *

php netflixchk.php


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
