#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install


sleep 0.1
 

echo -e "      $red                                    [0]back"
sleep 0.1
echo -e "$reset"                  
sleep 0.1
echo "             [1]Download santet-online"
sleep 0.1
echo "             [2]Download MBF"
sleep 0.1
echo "             [3]Download Tmux-Bunch "
sleep 0.1
echo "             [4]Download Tool-x⬇️ "
sleep 0.1
echo "             [5]Download sqlmap  "
sleep 0.1
echo "             [6]Download EasY_HaCk "
sleep 0.1
echo "             [7]Download Optiva-Framework "
sleep 0.1
echo "             [8]Download guardn "
sleep 0.1
echo "             [9]Download blackeye "
sleep 0.1
echo "             [10]Download setoolkit "
sleep 0.1
echo "             [11]Download Email-bomber "
sleep 0.1
echo "             [12]Download ccgen "
sleep 0.1
echo "             [13]Download Fakecall "
sleep 0.1
echo "             [14]Download OSIF "
sleep 0.1
echo "             [15]Download tmvenom "
sleep 0.1
echo "             [16]Download Striker "
sleep 0.1
echo "             [17]Download A-Rat "
sleep 0.1
echo "             [18]Download BeEF  "
sleep 0.1
echo "             [19]Download routersploit"
sleep 0.1
echo "             [20]Download Lazymux "
sleep 0.2
echo "             [21]Download SocialFish"
sleep 0.2
echo "             [22]Download D-TECT "
sleep 0.2
echo "             [23]Download Hash Cracker"
sleep 0.2
echo "             [24]Download IPGeoLocation"
sleep 0.2
echo "             [25]Download termux-ohmyzsh"
sleep 0.2
echo "             [26]Download Tool Termux"
sleep 0.3
echo "             [27]Download NetflixChk"
sleep 0.3
echo "             [28]Download Ghost"
sleep 0.3
echo "             [29]Download payload5 "
sleep 0.3
echo -e "$green"
sleep 0.3

