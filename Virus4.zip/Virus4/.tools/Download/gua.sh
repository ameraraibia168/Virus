cd

rm -rf guardn

pkg install git -y

git clone https://github.com/Noxturnix/guardn


cd guardn
pip install requests
chmod +x guardn.py


python3 guardn.py



sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
