cd

rm -rf setoolkit.sh

rm -rf setoolkit

apt install curl -y

curl -LO https://raw.githubusercontent.com/Hax4us/setoolkit/master/setoolkit.sh

sh setoolkit.sh

cd setoolkit

./setup.py install

./setoolkit


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
