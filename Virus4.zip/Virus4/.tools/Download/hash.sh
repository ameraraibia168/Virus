cd

rm -rf hasher

apt update 

apt upgrade

apt install git

apt install python

apt install python2

git clone https://github.com/ciku370/hasher

cd hasher


python2 hash.py

sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
