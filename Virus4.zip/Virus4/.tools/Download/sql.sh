cd

rm -rf sqlmap

pkg install git -y

git clone https://github.com/sqlmapproject/sqlmap

cd sqlmap 

ls

chmod +x sqlmap.py

python2 sqlmap.py


sleep 0.3


echo ""
echo ""
read -p "                   ------------>entar"
cd $HOME/Virus4
python2 Virus4.py
