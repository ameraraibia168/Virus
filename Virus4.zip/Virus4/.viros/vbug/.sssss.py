def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 5000)
h = "  \033[1;33m[\033[1;32m*\033[1;33m] Welcome to my friend on {\033[1;36mVirus4\033[1;33m} Programmer [\033[1;32mAmer Amerr\033[1;33m] "

kk(h)





