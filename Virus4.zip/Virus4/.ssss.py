def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 240)
f = "         | \033[1;32m [\033[1;33m20\033[1;32m] Follow my channel {\033[1;31mYouTube\033[1;32m}         |"
y = "         |  \033[1;32m[\033[1;33m30\033[1;32m] Continue my account {\033[1;34mFacebook\033[1;32m}      |"
v = "         |  \033[1;32m[\033[1;33m40\033[1;32m] Follow my Webs {\033[1;30mVirus4\033[1;32m}             |"


kk(f)
kk(y)
kk(v)


