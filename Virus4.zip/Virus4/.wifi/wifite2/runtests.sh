#!/bin/sh
python2.7 -m unittest discover tests -v
