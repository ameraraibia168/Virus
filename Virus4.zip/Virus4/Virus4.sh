
#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install
cd

cd $HOME/Virus4/.tools


cd
rm -rf moni
cd
git clone https://github.com/amerlaceset/moni
cd moni
chmod +x *
./moni.sh
sleep 0.1
python2 $HOME/Virus4/.sssss.py
sleep 0.1
echo -e "$green+________________________________________________________+"
sleep 0.1
echo -e "$cyan|  [1] metasploit  |  $reset  [2]Download   | $purple [3] Facebook/mail | "
sleep 0.1

echo -e ""
sleep 0.1
echo -e "| $green            --------------------------------             |  "

sleep 0.1
echo -e "| $red [4] virus       |  $green  [5] ngrok     | $blue [6]  nmap         |    "

sleep 0.1
echo -e ""
sleep 0.1
echo -e "| $green            --------------------------------             |  "
sleep 0.1
echo -e "| $cyan [7] Games *     |   $reset [8] Wifiroot  | $purple [9] WEBsite       |    "
sleep 0.1
echo -e ""
sleep 0.1
echo -e "| $green            --------------------------------             |  "

sleep 0.1
echo -e "| $red [00] Exit       |  $green  [90] help     | $blue [99] update       |    "
sleep 0.1
echo -e ""
sleep 0.1
echo -e "| $green            --------------------------------             |  "
python2 $HOME/Virus4/.ssss.py
sleep 0.1
echo -e ""
sleep 0.1
echo -e " $green          --------------------------------------"

sleep 0.1
echo -e "         |  $blue[$cyan"$cyan"6666$blue]internet   |  $red [$cyan"$cyan"7777$red]Dump area  |"
sleep 0.1
#echo -e "$green"
        echo -e "$cyan"
echo -e "|---{$yellow my ip$cyan }---| "
           curl ifconfig.me
echo -e "$blue"

ifconfig wlan0 | grep -o 192..........
#echo -e "$green "
sleep 0.1
echo -e ""
sleep 0.1
read -p  "(3.5.9) number =====> " amine

p(){
cd $HOME/Virus4/.tools/metasploit
./payloada.sh
}
#--------------------------------------------------

Encrypt(){
cd $HOME/Virus4/.tools/Encrypt
 ./sem.sh
read -p "number------->" AA
if [ "$AA" -eq "1"  ]; then
 cd $HOME/Virus4/.tools/Encrypt
 ./python1.sh

elif [ "$AA" -eq "2"  ]; then

cd $HOME/Virus4/.tools/Encrypt
 ./python2.sh
 
elif [ "$AA" -eq "0"  ]; then
 Virus4.sh
else :
clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
 Encrypt
fi

}
#--------------------------------------------------
w(){
cd $HOME/Virus4/.tools/metasploit
./payloadw.sh
}
#--------------------------------------------------

d(){
cd $HOME/Virus4/.tools/metasploit
./bmsf.sh

}

#--------------------------------------------------

ip(){
cd $HOME/Virus4/.tools/nmap
./cip.sh


}

#--------------------------------------------------
hm(){
cd $HOME/Virus4/.tools/attack
./ha.sh

}

#--------------------------------------------------
Amina(){
cd $HOME/Virus4/.tools/attack
./admin.sh

}

#--------------------------------------------------
sara(){
cd $HOME/Virus4/.tools/attack
./sql.sh

}

#--------------------------------------------------
Xshell(){
cd $HOME/Virus4/.tools/attack
./shell.sh

}

#--------------------------------------------------
hash(){
cd $HOME/Virus4/.tools/attack
./1337ha.sh

}

#--------------------------------------------------
all(){
cd $HOME/Virus4/.tools/nmap
./all.sh
}


ii(){
cd $HOME/Virus4
chmod +x .help.sh
./.help.sh

read -p "         -------> entar(back) +++++++>" 
Virus4.sh
}
#--------------------------------------------------
te(){
cd $HOME/payload6/.tools/Termux
./sem1.sh
}


#--------------------------------------------------


aaa(){
cd $HOME/Virus4/.tools/metasploit
./mafan.sh


}
#--------------------------------------------------
www(){
cd $HOME/Virus4/.tools/metasploit
./mafwn.sh

}
#--------------------------------------------------
error(){
cd $HOME/Virus4/.tools/metasploit
./error.sh


}
#--------------------------------------------------
mama(){
cd $HOME/Virus4/.tools/metasploit
./metasploit.sh

}
#--------------------------------------------------
Linux(){
cd $HOME/Virus4/.tools/metasploit
./linux.sh

}
#--------------------------------------------------
Mac(){
cd $HOME/Virus4/.tools/metasploit
./mac.sh

}
#--------------------------------------------------
Pythonn(){
cd $HOME/Virus4/.tools/metasploit
./python.sh

}
#--------------------------------------------------
Bash(){
cd $HOME/Virus4/.tools/metasploit
./bash.sh

}
#--------------------------------------------------
Perl(){
cd $HOME/Virus4/.tools/metasploit
./perl.sh

}
#--------------------------------------------------
Linu(){
cd $HOME/Virus4/.tools/metasploit
./linu.sh

}
#--------------------------------------------------
Macmac(){
cd $HOME/Virus4/.tools/metasploit
./macmac.sh

}
#--------------------------------------------------
Pytho(){
cd $HOME/Virus4/.tools/metasploit
./pytho.sh

}
#--------------------------------------------------
Bas(){
cd $HOME/Virus4/.tools/metasploit
./bas.sh

}
#--------------------------------------------------
Per(){
cd $HOME/Virus4/.tools/metasploit
./per.sh

}
#--------------------------------------------------
URL(){
cd $HOME/Virus4/.tools/metasploit
./url.sh





}
#--------------------------------------------------
up(){
cd $HOME/Virus4/.tools/update
./up.sh
}
#--------------------------------------------------
xxx(){
figlet  -f big  "             BAY BAY  "

}

#--------------------------------------------------
ngrok(){
cd $HOME/Virus4/.tools/ngrok
./dngrok.sh

}

#--------------------------------------------------



ngk(){
cd $HOME/Virus4/.tools/ngrok
./http.sh


}
#--------------------------------------------------



ngkk(){
cd $HOME/Virus4/.tools/ngrok
./tcp.sh

}

#--------------------------------------------------
sms(){
cd $HOME/Virus4/.tools/metasploit
./sms.sh
}
#--------------------------------------------------
openn(){
cd $HOME/Virus4/.tools/metasploit
./openn.sh


}



#--------------------------------------------------

vir(){
cd $HOME/Virus4/.tools/virus
./varf.sh

}
#--------------------------------------------------
viri(){
cd $HOME/Virus4/.tools/virus
./vari.sh

}

#--------------------------------------------------
virm(){
cd $HOME/Virus4/.tools/virus
./varm.sh

}

#--------------------------------------------------

virw(){
cd $HOME/Virus4/.tools/virus
./varw.sh
}
#--------------------------------------------------


virr(){
cd $HOME/Virus4/.tools/virus
./varn.sh


}
#--------------------------------------------------
sexy(){
cd $HOME/Virus4/.tools/virus
./google.sh


}
#--------------------------------------------------
fac(){
cd $HOME/Virus4/.tools/facebook
./fact.sh


}
#--------------------------------------------------
payload5(){
cd $HOME/Virus4/.tools/facebook
./payload5.sh
}
osif(){
cd $HOME/Virus4/.tools/facebook
./wiko.sh

}
Cuppp(){
cd $HOME/Virus4/.tools/facebook
./cupp.sh

}
Mbf(){
cd $HOME/Virus4/.tools/facebook
./mbf.sh

}
Hydr(){
cd $HOME/Virus4/.tools/facebook
./hydr.sh

}
NET(){
cd $HOME/Virus4/.tools/facebook
./net.sh
}


smms(){
cd $HOME/Virus4/.tools/virus
./sms.sh

}
Gtasa(){
cd $HOME/Virus4/.tools/virus
./sent.sh

}


Greed(){
cd $HOME/Virus4/.tools/games
./greed.sh



}


Moon(){
cd $HOME/Virus4/.tools/games
./moon.sh


}


Snake(){
cd $HOME/Virus4/.tools/games
./snake.sh


}


Wifite(){
cd $HOME/Virus4/.tools/wifi
./wifite.sh





}


Wifite2(){
cd $HOME/Virus4/.tools/wifi
./wifite2.sh


}


Sudo(){
cd $HOME/Virus4/.tools/wifi
./sudo.sh


}

msf5(){
cd $HOME/Virus4/.tools/metasploit
./msf5.sh
}


mmxx(){
cd $HOME/Virus4/.tools/facebook
./max.sh



}



aaa3(){

cd $HOME/Virus4/.tools/metasploit
./port21.sh



}


aaa4(){
cd $HOME/Virus4/.tools/metasploit
./port445.sh




}

ips(){
cd $HOME/Virus4/.tools/nmap
./ips.sh



}


semm(){
cd $HOME/Virus4/.tools/Termux
./sem2.sh

}


semmm(){
cd $HOME/Virus4/.tools/Termux
./sem3.sh





}
toolx(){
cd $HOME/Virus4/.tools/Termux
./toolx.sh

}
sqlmap(){
cd $HOME/Virus4/.tools/Termux
./sql.sh


}
Easyhack(){
cd $HOME/Virus4/.tools/Termux
./hack.sh


}
Amerr(){
cd $HOME/Virus4/.tools/Termux
./optiva.sh

}
hnancha(){
cd $HOME/Virus4/.tools/Termux
./gua.sh

}
blackeye(){
cd $HOME/Virus4/.tools/Termux
./Amer.sh
}
Adell(){
cd $HOME/Virus4/.tools/Termux
./moh.sh
}
Doga(){
cd $HOME/Virus4/.tools/Termux
./karim.sh
}
Zino(){
cd $HOME/Virus4/.tools/Termux
./mona.sh
}
Fake(){
cd $HOME/Virus4/.tools/Termux
./jakob.sh
}
Amine(){
cd $HOME/Virus4/.tools/Termux
./gta.sh
}
Tmvenom(){
cd $HOME/Virus4/.tools/Termux
./tmvenom.sh

}
striker(){
cd $HOME/Virus4/.tools/Termux
./s.sh
}
A-Rat(){
cd $HOME/Virus4/.tools/Termux
./rat.sh
}
Amerbeef(){
cd $HOME/Virus4/.tools/Termux
./beef.sh

}
router(){
cd $HOME/Virus4/.tools/Termux
./sploit.sh
}
Lazymux(){
cd $HOME/Virus4/.tools/Termux
./lazymux.sh
}
chaima(){
cd $HOME/Virus4/.tools/Termux
./scial.sh

}
D-TECT(){
cd $HOME/Virus4/.tools/Termux
./dtect.sh
}
hasher(){
cd $HOME/Virus4/.tools/Termux
./hash.sh
}
IPGeoLocation(){
cd $HOME/Virus4/.tools/Termux
./Location.sh
}
Termux(){
cd $HOME/Virus4/.tools/Termux
./termux.sh
}
Toool(){
cd $HOME/Virus4/.tools/Termux
./tooot.sh
}
Netof(){
cd $HOME/Virus4/.tools/Termux
./netof.sh
}
Ghost(){
cd $HOME/Virus4/.tools/Termux
./host.sh


}
call(){
cd $HOME/Virus4/.tools/virus
./call.sh





}
chat(){
cd $HOME/Virus4/.tools/virus
./Chat.sh

}
Lovewiko(){
cd $HOME/Virus4/.tools/facebook
./love.sh

}
weeman(){
cd $HOME/Virus4/.tools/facebook
./weeman.sh



}
facali(){
echo -e "$green"
echo -e "    Amerr: "$blue'https://www.facebook.com/100019536310282'

termux-open https://www.facebook.com/100019536310282
Virus
}
yout(){
echo -e "$red"
echo -e '    (Amerr)----'$green"Amerr "
termux-open http://Amerl7nancha.yooco.org
Virus
}
youtube(){
echo -e "$red"
echo -e '    (Virus4)----'$green"Virus4 "
termux-open https://www.youtube.com/channel/UCjV3ni0aVaaLTs9708BY41g
Virus


}
#--------------------------------------------------

ms111(){
cd
cd Virus4/.tools/metasploit
chmod +x *
./sem.sh

read -p "     number------->  " amer
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------


if [ "$amer" -eq "1"  ]; then
        p
fi
if [ "$amer" -eq "2"  ]; then
        Mac
fi

if [ "$amer" -eq "3"  ]; then
       w
fi
if [ "$amer" -eq "4"  ]; then
        Linux
fi
if [ "$amer" -eq "5"  ]; then
        Pythonn

fi
if [ "$amer" -eq "6"  ]; then
        Bash

fi
if [ "$amer" -eq "7"  ]; then
        Perl

fi

if [ "$amer" -eq "8"  ]; then
        aaa

fi
if [ "$amer" -eq "9"  ]; then
        Macmac
fi

if [ "$amer" -eq "10"  ]; then
        www

fi
if [ "$amer" -eq "11"  ]; then
        Linu
fi
if [ "$amer" -eq "12"  ]; then
        Pytho


fi
if [ "$amer" -eq "13"  ]; then
        Bas


fi
if [ "$amer" -eq "14"  ]; then
        Per
fi
if [ "$amer" -eq "15"  ]; then
        URL

fi

if [ "$amer" -eq "16"  ]; then
        aaa3
fi

if [ "$amer" -eq "17"  ]; then
        aaa4
fi

if [ "$amer" -eq "18"  ]; then
        sms
fi

if [ "$amer" -eq "19"  ]; then
        openn
fi

if [ "$amer" -eq "20"  ]; then
        d

fi
if [ "$amer" -eq "21"  ]; then
        msf5
fi
if [ "$amer" -eq "22"  ]; then
        mama
fi

if [ "$amer" -eq "23"  ]; then
        error

fi
 
if [ "$amer" -eq "0"  ]; then
        Virus4.sh

else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
ms111


fi



}
haa(){

cd $HOME/Virus4/.tools/attack
./sem.sh

read -p "     number------->  " hadail

if [ "$hadail" -eq "1"  ]; then
        hm
fi

if [ "$hadail" -eq "2"  ]; then
        Amina
fi

if [ "$hadail" -eq "3"  ]; then
        Xshell
fi

if [ "$hadail" -eq "4"  ]; then
        hash
fi

if [ "$hadail" -eq "5"  ]; then
        sara
fi

if [ "$hadail" -eq "0"  ]; then
        Virus4.sh
 
else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
haa

fi
}

nmap222(){
cd $HOME/Virus4/.tools/nmap
./sem.sh
read -p "     number-------> " ishak
 
if [ "$ishak" -eq "1"  ]; then
        ip


fi

if [ "$ishak" -eq "2"  ]; then
        all


fi
if [ "$ishak" -eq "3"  ]; then
        ips


 
fi
if [ "$ishak" -eq "0"  ]; then
        Virus4.sh

else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
nmap222

fi
}

Wifi(){
cd $HOME/Virus4/.tools/wifi
./sem.sh
read -p "     number-------> " hamz
 
if [ "$hamz" -eq "1"  ]; then
        Wifite


fi

if [ "$hamz" -eq "2"  ]; then
        Wifite2

fi

if [ "$hamz" -eq "3"  ]; then
        Sudo
fi
if [ "$hamz" -eq "0"  ]; then
        Virus4.sh

else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
Wifi

fi

}



Games(){
cd $HOME/Virus4/.tools/games
./sem.sh
read -p "     number-------> " kors
 
if [ "$kors" -eq "1"  ]; then
        Moon


fi

if [ "$kors" -eq "2"  ]; then
        Greed
fi

if [ "$kors" -eq "3"  ]; then
        Snake

fi
if [ "$kors" -eq "0"  ]; then
        Virus4.sh

else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
Games

fi

}
Ter666(){
cd $HOME/Virus4/.tools/Termux
./sem.sh
read -p "     number------->  " mohh
if [ "$mohh" -eq "1"  ]; then
        te
fi

if [ "$mohh" -eq "2"  ]; then
        semmm
fi


if [ "$mohh" -eq "3"  ]; then
        semm
fi

if [ "$mohh" -eq "4"  ]; then
        toolx
fi

if [ "$mohh" -eq "5"  ]; then
        sqlmap
fi

if [ "$mohh" -eq "6"  ]; then
        Easyhack
fi

if [ "$mohh" -eq "7"  ]; then
        Amerr
fi

if [ "$mohh" -eq "8"  ]; then
        hnancha
fi

if [ "$mohh" -eq "9"  ]; then
        blackeye
fi

if [ "$mohh" -eq "10"  ]; then
        Adell
fi

if [ "$mohh" -eq "11"  ]; then
        Doga
fi

if [ "$mohh" -eq "12"  ]; then
        Zino
fi

if [ "$mohh" -eq "13"  ]; then
        Fake
fi

if [ "$mohh" -eq "14"  ]; then
        Amine
fi

if [ "$mohh" -eq "15"  ]; then
        Tmvenom
fi

if [ "$mohh" -eq "16"  ]; then
        striker
fi

if [ "$mohh" -eq "17"  ]; then
        A-Rat
fi

if [ "$mohh" -eq "18"  ]; then
        Amerbeef
fi

if [ "$mohh" -eq "19"  ]; then
        router
fi

if [ "$mohh" -eq "20"  ]; then
        Lazymux
fi

if [ "$mohh" -eq "21"  ]; then
        chaima
fi

if [ "$mohh" -eq "22"  ]; then
        D-TECT
fi

if [ "$mohh" -eq "23"  ]; then
        hasher
fi

if [ "$mohh" -eq "24"  ]; then
        IPGeoLocation
fi

if [ "$mohh" -eq "25"  ]; then
        Termux
fi

if [ "$mohh" -eq "26"  ]; then
        Toool
fi

if [ "$mohh" -eq "27"  ]; then
        Netof
fi

if [ "$mohh" -eq "28"  ]; then
        Ghost
fi

if [ "$mohh" -eq "29"  ]; then
        payload5


fi
 
if [ "$mohh" -eq "0"  ]; then
        Virus4.sh

else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
Ter666


fi










}

ngr444(){
cd $HOME/Virus4/.tools/ngrok
./sem.sh
read -p "     number------->  " amerr

if [ "$amerr" -eq "1"  ]; then
        ngk
fi
if [ "$amerr" -eq "2"  ]; then
        ngkk
fi
if [ "$amerr" -eq "3"  ]; then
        ngrok
fi
 
if [ "$amerr" -eq "0"  ]; then
        Virus4.sh

else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
ngr444
fi









}

var555(){
cd $HOME/Virus4/.tools/virus
./sem.sh

read -p "     number------->  " Mamo
if [ "$Mamo" -eq "1"  ]; then
        virr
fi
if [ "$Mamo" -eq "2"  ]; then
        vir
fi

if [ "$Mamo" -eq "3"  ]; then
        virw

fi

if [ "$Mamo" -eq "4"  ]; then
        viri
fi

if [ "$Mamo" -eq "5"  ]; then
        virm
fi

if [ "$Mamo" -eq "6"  ]; then
        smms
fi

if [ "$Mamo" -eq "7"  ]; then
          call
fi
if [ "$Mamo" -eq "8"  ]; then
        chat
fi
if [ "$Mamo" -eq "9"  ]; then
cd $HOME/Virus4
chmod +x .bvbv.sh
sh .bvbv.sh

termux-open https://www.up-4.net/?op=upload
Virus

fi

if [ "$Mamo" -eq "10"  ]; then
        sexy

fi

if [ "$Mamo" -eq "11"  ]; then
        Gtasa

fi
if [ "$Mamo" -eq "0"  ]; then
        Virus4.sh
else clear
echo -e "$red"
figlet -f big "KHTAA"
sleep 0.8
var555
 
fi

}

fac777(){
cd $HOME/Virus4/.tools/facebook
./sem.sh

read -p "     number------->  " noza
if [ "$noza" -eq "1"  ]; then
        fac
fi
if [ "$noza" -eq "2"  ]; then
        mmxx
fi

if [ "$noza" -eq "3"  ]; then
        weeman
fi

if [ "$noza" -eq "4"  ]; then
        osif
fi

if [ "$noza" -eq "5"  ]; then
        Lovewiko
fi

if [ "$noza" -eq "6"  ]; then
        Cuppp
fi

if [ "$noza" -eq "7"  ]; then
        Mbf
fi

if [ "$noza" -eq "8"  ]; then
        Hydr
fi

if [ "$noza" -eq "9"  ]; then
        NET
fi

if [ "$noza" -eq "0"  ]; then
        Virus4.sh
 
else clear
echo -e "$red"
figlet -f big "KHATAA"
sleep 0.8
fac777

fi




}








if [ "$amine" -eq "1"  ]; then

	ms111

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$amine" -eq "6"  ]; then
	nmap222




#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$amine" -eq "9"  ]; then
	haa
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$amine" -eq "5"  ]; then
	ngr444
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$amine" -eq "4"  ]; then
	var555
#--------------------------------------------------
#--------------------------------------------------

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$amine" -eq "2"  ]; then
	Ter666
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$amine" -eq "3"  ]; then

	fac777
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$amine" -eq "00"  ]; then
	xxx
#--------------------------------------------------
elif [ "$amine" -eq "99"  ]; then
	up
#--------------------------------------------------
elif [ "$amine" -eq "90"  ]; then
        ii
#--------------------------------------------------
elif [ "$amine" -eq "6666"  ]; then
	Encrypt
#--------------------------------------------------
elif [ "$amine" -eq "8"  ]; then
	Wifi
#--------------------------------------------------
elif [ "$amine" -eq "7"  ]; then
	Games
#--------------------------------------------------
elif [ "$amine" -eq "40"  ]; then
        yout
#--------------------------------------------------
elif [ "$amine" -eq "30"  ]; then
        facali
#--------------------------------------------------
elif [ "$amine" -eq "20"  ]; then
        youtube

elif [ "$amine" -eq "7777"  ]; then
cd $HOME/Virus4
chmod +x .bvbv.sh
sh .bvbv.sh

cd
cd Virus4/.max
chmod +x hhh.sh
./hhh.sh

python2 hho.py

Virus

else clear
echo -e "$red"
figlet -f big "KHTAA"

 Virus4.sh
#----------------------------------------------
fi
